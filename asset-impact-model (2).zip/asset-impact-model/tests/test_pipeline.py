"""
tests/test_pipeline.py
======================
Tests for the end-to-end orchestration.

Why these tests stub the siblings
---------------------------------
Both neighbouring models are replaced with stubs, so this suite passes on a
machine where neither is installed and a stage-1 outage cannot make stage 3
look broken. What is being tested here is the *wiring*: that severity flows
into asset impact, that asset impact flows into priority, that manual overrides
win, and — the one worth catching — that the severity model is called exactly
**once** per request rather than twice.
"""

from __future__ import annotations

from src import clients, config
from src.pipeline import score_request, score_requests
from src.utils import UpstreamModelUnavailableError, ValidationError


def _expect_raises(exc_type, fn, *args, **kwargs):
    try:
        fn(*args, **kwargs)
    except exc_type:
        return
    raise AssertionError(f"Expected {exc_type.__name__}")


class _Stubs:
    """Stand-ins for the severity and priority models, with call counting."""

    def __init__(self, severity: str = "Critical"):
        self.severity = severity
        self.severity_calls: list[str] = []
        self.priority_calls: list[dict] = []

    def severity_fn(self, text: str) -> dict:
        self.severity_calls.append(text)
        return {"severity": self.severity, "score": 25, "confidence": 0.88}

    def priority_fn(self, **kwargs) -> dict:
        self.priority_calls.append(kwargs)
        return {
            "predicted_severity": kwargs["severity"],
            "severity_score": 25,
            "asset_impact_score": {"High": 30, "Medium": 20, "Low": 10}[
                kwargs["asset_impact"]
            ],
            "traffic_score": 25,
            "due_date_score": 13,
            "priority_score": 93,
            "priority_class": "Critical",
        }

    def __enter__(self):
        clients._CACHE["severity"] = self.severity_fn
        clients._CACHE["priority"] = self.priority_fn
        return self

    def __exit__(self, *exc_info):
        clients.reset()
        return False


# --------------------------------------------------------------------------- #
# Wiring
# --------------------------------------------------------------------------- #
def test_severity_flows_through_to_the_priority_model():
    with _Stubs("Critical") as stubs:
        result = score_request(
            reason_description="Track fracture detected",
            traffic="High", due_date="2026-09-25", request_date="2026-09-18",
            strategy="rules",
        )
        assert stubs.severity_calls == ["Track fracture detected"]
        assert stubs.priority_calls[0]["severity"] == "Critical"
        assert result["priority_class"] == "Critical"


def test_the_severity_model_is_called_exactly_once_per_request():
    """
    Stage 3 needs the severity and so does stage 2's own scoring. Passing it
    forward rather than the raw text halves the NLP calls and guarantees both
    stages see the same value.
    """
    with _Stubs() as stubs:
        score_request(reason_description="Signal failure", traffic="Medium",
                      due_date="2026-09-25", request_date="2026-09-18",
                      strategy="rules")
        assert len(stubs.severity_calls) == 1
        assert "reason_description" not in stubs.priority_calls[0]


def test_asset_impact_is_computed_and_passed_to_the_priority_model():
    with _Stubs("Critical") as stubs:
        result = score_request(reason_description="Track fracture", traffic="High",
                               due_date="2026-09-25", request_date="2026-09-18",
                               strategy="rules")
        passed = stubs.priority_calls[0]["asset_impact"]
        assert passed in config.ASSET_IMPACT_LEVELS
        assert result["asset_impact"] == passed


def test_the_priority_model_receives_an_unchanged_interface():
    """Stage 2 must keep taking asset_impact as a plain input feature."""
    with _Stubs() as stubs:
        score_request(reason_description="x", traffic="Low", due_date="2026-10-01",
                      request_date="2026-09-18", strategy="rules")
        call = stubs.priority_calls[0]
        assert set(call) >= {"asset_impact", "traffic", "due_date", "severity"}


# --------------------------------------------------------------------------- #
# Overrides
# --------------------------------------------------------------------------- #
def test_a_supplied_severity_skips_stage_one():
    with _Stubs() as stubs:
        score_request(traffic="High", due_date="2026-09-25", severity="Major",
                      request_date="2026-09-18", strategy="rules")
        assert stubs.severity_calls == []


def test_a_supplied_asset_impact_wins_over_the_model():
    """The manual workflow stays available — a model must not overrule an engineer."""
    with _Stubs() as stubs:
        result = score_request(traffic="Low", due_date="2026-12-01", severity="Minor",
                               asset_impact="High", request_date="2026-09-18",
                               strategy="rules")
        assert result["asset_impact"] == "High"
        assert stubs.priority_calls[0]["asset_impact"] == "High"
        assert result["trace"]["asset_impact"]["source"] == "supplied"


# --------------------------------------------------------------------------- #
# Trace
# --------------------------------------------------------------------------- #
def test_the_trace_records_every_stage():
    with _Stubs() as _:
        result = score_request(reason_description="Track fracture", traffic="High",
                               due_date="2026-09-25", request_date="2026-09-18",
                               strategy="rules")
        assert set(result["trace"]) == {"severity", "asset_impact", "priority"}
        assert result["trace"]["severity"]["source"] == "maintenance_severity_model"
        assert result["trace"]["severity"]["confidence"] == 0.88


def test_the_trace_can_be_switched_off():
    with _Stubs() as _:
        result = score_request(reason_description="x", traffic="High",
                               due_date="2026-09-25", request_date="2026-09-18",
                               strategy="rules", return_trace=False)
        assert "trace" not in result


def test_the_response_is_json_serialisable():
    import json

    with _Stubs() as _:
        json.dumps(score_request(reason_description="x", traffic="High",
                                 due_date="2026-09-25", request_date="2026-09-18",
                                 strategy="rules"), default=str)


# --------------------------------------------------------------------------- #
# Failure handling
# --------------------------------------------------------------------------- #
def test_missing_due_date_is_rejected():
    with _Stubs() as _:
        _expect_raises(ValidationError, score_request, reason_description="x",
                       traffic="High")


def test_missing_both_reason_and_severity_is_rejected():
    with _Stubs() as _:
        _expect_raises(ValidationError, score_request, traffic="High",
                       due_date="2026-09-25")


def test_an_invalid_traffic_level_is_rejected():
    with _Stubs() as _:
        _expect_raises(ValidationError, score_request, reason_description="x",
                       traffic="Extreme", due_date="2026-09-25")


def test_a_failing_severity_model_surfaces_as_a_service_error():
    stubs = _Stubs()
    with stubs:
        def boom(text):
            raise RuntimeError("model file corrupt")

        clients._CACHE["severity"] = boom
        _expect_raises(UpstreamModelUnavailableError, score_request,
                       reason_description="x", traffic="High",
                       due_date="2026-09-25", strategy="rules")


def test_batch_scoring_survives_a_bad_row():
    with _Stubs() as _:
        results = score_requests(
            [
                {"reason_description": "ok", "traffic": "High",
                 "due_date": "2026-09-25", "request_date": "2026-09-18"},
                {"reason_description": "bad", "traffic": "Nonsense",
                 "due_date": "2026-09-25", "request_date": "2026-09-18"},
            ],
            strategy="rules",
        )
        assert results[0]["priority_class"] == "Critical"
        assert results[1]["error_type"] == "ValidationError"


if __name__ == "__main__":
    import sys

    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
    from _runner import run_module

    raise SystemExit(run_module(sys.modules[__name__]))
