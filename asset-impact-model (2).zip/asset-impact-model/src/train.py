"""
train.py  —  Deliverable 2
==========================
Trains, evaluates and persists the asset-impact classifier.

    python -m src.train
    python -m src.train --data data/demo_with_asset_features.csv

    signal analysis -> split -> cross-validate candidates -> select -> refit
    -> evaluate against the majority baseline -> archive previous -> save

Why the signal analysis runs first
----------------------------------
Because a classifier trained on noise does not fail — it returns a majority-class
constant wearing an accuracy score. ``diagnostics.analyse`` establishes the
ceiling before any model is fitted, so the training log opens with what is
actually achievable rather than closing with a number nobody can interpret.

Everything is packaged as one ``sklearn.pipeline.Pipeline`` containing the
encoder and the classifier together, so the transform applied at inference is
provably the one fitted in training.
"""

from __future__ import annotations

import argparse
import platform
import shutil
import sys
from typing import Any
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

from src import config, diagnostics
from src.evaluate import feature_importances, save_reports
from src.utils import (
    DatasetError,
    InsufficientSignalError,
    ensure_dirs,
    get_logger,
    normalise_column,
    save_joblib,
    save_json,
    timestamp,
)

logger = get_logger(__name__)

# Initialise the optional estimator name so static analysers know it exists
# even when xgboost is not installed.
XGBClassifier: Any = None
try:
    from xgboost import XGBClassifier

    XGBOOST_AVAILABLE = True
except ImportError:  # pragma: no cover
    XGBOOST_AVAILABLE = False
    logger.info("xgboost not installed — comparing the scikit-learn candidates only.")


# --------------------------------------------------------------------------- #
# Data
# --------------------------------------------------------------------------- #
def load_training_data(path: Path | None = None) -> pd.DataFrame:
    """Load and validate the dataset produced by ``build_dataset.py``."""
    path = Path(path) if path else config.TRAINING_DATASET
    if not path.exists():
        raise DatasetError(
            f"Training dataset not found: {path}\nBuild it first:\n"
            f"    python -m src.build_dataset --priority-data <your priority CSV>"
        )

    frame = pd.read_csv(path)
    logger.info("Loaded %d row(s) from %s", len(frame), path.name)

    for column, levels in (
        (config.TARGET_COLUMN, config.ASSET_IMPACT_LEVELS),
        (config.SEVERITY_COLUMN, config.SEVERITY_LEVELS),
        (config.TRAFFIC_COLUMN, config.TRAFFIC_LEVELS),
    ):
        if column in frame.columns:
            frame[column] = normalise_column(frame[column], levels)

    required = [config.TARGET_COLUMN] + [
        c for c in config.BASE_FEATURES if c in frame.columns
    ]
    missing = [c for c in [config.TARGET_COLUMN] + config.BASE_FEATURES
               if c not in frame.columns]
    if missing:
        raise DatasetError(
            f"{path.name} is missing required column(s) {missing}. "
            f"Found: {list(frame.columns)}"
        )

    dropped = frame[required].isna().any(axis=1).sum()
    if dropped:
        logger.warning("Dropping %d row(s) with missing or unrecognised values.", dropped)
    frame = frame.dropna(subset=required).reset_index(drop=True)

    if frame.empty:
        raise DatasetError(f"No usable rows in {path}.")
    logger.info(
        "Target distribution: %s", frame[config.TARGET_COLUMN].value_counts().to_dict()
    )
    return frame


# --------------------------------------------------------------------------- #
# Pipeline
# --------------------------------------------------------------------------- #
def build_preprocessor(categorical: list[str], numeric: list[str]) -> ColumnTransformer:
    """
    One-hot the categorical features; impute and scale any numeric ones.

    ``handle_unknown="ignore"`` keeps inference alive if a level appears that
    was absent from training — a new asset type added to the register, say.
    It encodes as all-zeros rather than raising. Validation in ``predict.py``
    catches unknown values for the two core features before they reach here;
    this is the second line of defence for the optional ones.
    """
    transformers: list[tuple[str, OneHotEncoder | Pipeline, list[str]]] = [
        ("categorical", OneHotEncoder(handle_unknown="ignore", sparse_output=False),
         categorical)
    ]
    if numeric:
        transformers.append(
            (
                "numeric",
                Pipeline([
                    ("impute", SimpleImputer(strategy="median")),
                    ("scale", StandardScaler()),
                ]),
                numeric,
            )
        )
    return ColumnTransformer(transformers, remainder="drop",
                             verbose_feature_names_out=False)


def get_candidate_models(n_classes: int) -> dict[str, object]:
    """Candidates, all with balanced class weights where the estimator supports it."""
    models: dict[str, object] = {
        "logistic_regression": LogisticRegression(
            random_state=config.RANDOM_SEED, **config.LOGISTIC_REGRESSION_PARAMS
        ),
        "decision_tree": DecisionTreeClassifier(
            random_state=config.RANDOM_SEED, **config.DECISION_TREE_PARAMS
        ),
        "random_forest": RandomForestClassifier(
            random_state=config.RANDOM_SEED, **config.RANDOM_FOREST_PARAMS
        ),
    }
    if XGBOOST_AVAILABLE:
        params = dict(config.XGBOOST_PARAMS)
        if n_classes <= 2:
            params["objective"] = "binary:logistic"
            params["eval_metric"] = "logloss"
        models["xgboost"] = XGBClassifier(random_state=config.RANDOM_SEED, **params)
    return models


def build_pipeline(model, categorical: list[str], numeric: list[str]) -> Pipeline:
    return Pipeline([
        ("preprocess", build_preprocessor(categorical, numeric)),
        ("classifier", model),
    ])


# --------------------------------------------------------------------------- #
# Comparison and selection
# --------------------------------------------------------------------------- #
def compare_models(X, y, models, categorical, numeric) -> dict[str, dict]:
    """Cross-validate every candidate on the training split."""
    rarest = int(pd.Series(y).value_counts().min())
    folds = min(config.CV_FOLDS, rarest)
    if folds < config.CV_FOLDS:
        logger.warning("Reducing cross-validation to %d fold(s).", folds)

    results: dict[str, dict] = {}
    for name, model in models.items():
        try:
            if folds >= 2:
                cv = StratifiedKFold(n_splits=folds, shuffle=True,
                                     random_state=config.RANDOM_SEED)
                scores = cross_val_score(
                    build_pipeline(model, categorical, numeric), X, y,
                    cv=cv, scoring=config.SELECTION_METRIC, n_jobs=1,
                )
                results[name] = {
                    "cv_folds": folds,
                    "mean_f1_weighted": float(np.mean(scores)),
                    "std_f1_weighted": float(np.std(scores)),
                    "fold_scores": [float(s) for s in scores],
                }
                logger.info("%-22s CV weighted F1 = %.4f (+/- %.4f)", name,
                            results[name]["mean_f1_weighted"],
                            results[name]["std_f1_weighted"])
            else:
                from sklearn.metrics import f1_score

                fitted = build_pipeline(model, categorical, numeric).fit(X, y)
                score = f1_score(y, fitted.predict(X), average="weighted", zero_division=0)
                results[name] = {"cv_folds": 0, "mean_f1_weighted": float(score),
                                 "std_f1_weighted": 0.0, "fold_scores": [],
                                 "note": "training-set score, not cross-validated"}
                logger.info("%-22s train weighted F1 = %.4f", name, score)
        except Exception as exc:  # noqa: BLE001 - one bad candidate must not abort the run
            logger.error("Skipping %s — it failed during evaluation: %s", name, exc)
            results[name] = {"error": str(exc), "mean_f1_weighted": float("-inf")}
    return results


def select_best(results: dict[str, dict]) -> str:
    """Highest weighted F1, with one-standard-error tie-breaking toward simplicity."""
    usable = {k: v for k, v in results.items() if "error" not in v}
    if not usable:
        raise DatasetError("Every candidate model failed to train.")

    top = max(usable, key=lambda k: usable[k]["mean_f1_weighted"])
    top_score = usable[top]["mean_f1_weighted"]

    if not config.USE_ONE_SE_RULE:
        logger.info("Selected %s (weighted F1 = %.4f).", top, top_score)
        return top

    folds = usable[top].get("cv_folds", 0)
    std = usable[top].get("std_f1_weighted", 0.0)
    standard_error = (std / np.sqrt(folds)) if folds > 1 else 0.0
    threshold = top_score - standard_error

    tied = sorted(
        [k for k, v in usable.items() if v["mean_f1_weighted"] >= threshold],
        key=lambda k: (
            config.MODEL_COMPLEXITY_ORDER.index(k)
            if k in config.MODEL_COMPLEXITY_ORDER
            else len(config.MODEL_COMPLEXITY_ORDER)
        ),
    )
    best = tied[0]
    if best != top:
        logger.info(
            "One-SE rule: %s (%.4f) is within 1 SE (%.4f) of %s (%.4f) and "
            "simpler — selecting it.",
            best, usable[best]["mean_f1_weighted"], standard_error, top, top_score,
        )
    logger.info("Selected %s (weighted F1 = %.4f).", best, usable[best]["mean_f1_weighted"])
    return best


def archive_current_model() -> Path | None:
    existing = [p for p in (config.MODEL_PATH, config.METADATA_PATH) if p.exists()]
    if not existing:
        return None
    destination = config.ARCHIVE_DIR / timestamp()
    ensure_dirs(destination)
    for path in existing:
        shutil.copy2(path, destination / path.name)
    logger.info("Archived the previous model to %s", destination)
    return destination


# --------------------------------------------------------------------------- #
# Main routine
# --------------------------------------------------------------------------- #
def train(
    data_path: Path | str | None = None,
    *,
    test_size: float = config.TEST_SIZE,
    archive: bool = True,
    only_models: list[str] | None = None,
    force: bool = False,
) -> dict:
    """
    Run the full pipeline and persist the winning model.

    ``force=True`` saves the model even when it fails the lift check. The
    artefact is written either way if ``BLOCK_SAVE_ON_NO_LIFT`` is False; this
    flag is the per-run override.
    """
    ensure_dirs(config.MODELS_DIR, config.REPORTS_DIR, config.LOGS_DIR, config.ARCHIVE_DIR)

    # ---- 1. Data --------------------------------------------------------- #
    frame = load_training_data(Path(data_path) if data_path is not None else None)
    categorical, numeric = config.active_features(frame.columns)
    logger.info("Features in use: categorical=%s numeric=%s", categorical, numeric)

    extras = [f for f in categorical if f not in config.BASE_FEATURES]
    if not extras:
        logger.info(
            "Only severity and traffic are available. If the signal analysis "
            "below reports no signal, that is the reason — see the README."
        )

    # ---- 2. Signal analysis, before any model is fitted ------------------- #
    signal = diagnostics.analyse(frame, categorical)
    signal["feature_set_comparison"] = diagnostics.compare_feature_sets(frame)
    save_json(signal, config.REPORTS_DIR / "signal_analysis.json")

    if signal["verdict"] == "no_signal" and config.BLOCK_SAVE_ON_NO_LIFT and not force:
        raise InsufficientSignalError(
            f"The features {categorical} carry no usable information about "
            f"{config.TARGET_COLUMN}: the best possible classifier scores "
            f"{signal['ceiling_accuracy']:.4f} against a majority baseline of "
            f"{signal['majority_baseline_accuracy']:.4f}. Add asset attributes "
            f"(see config.OPTIONAL_ASSET_FEATURES) or pass --force to train anyway."
        )

    # ---- 3. Split -------------------------------------------------------- #
    X = frame[categorical + numeric]
    y = frame[config.TARGET_COLUMN]

    rarest = int(y.value_counts().min())
    can_split = test_size > 0 and rarest >= 2 and int(rarest * test_size) >= 1
    if can_split:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=config.RANDOM_SEED, stratify=y
        )
        logger.info("Split: %d train / %d hold-out.", len(X_train), len(X_test))
    else:
        logger.warning("Dataset too small to stratify — training on everything.")
        X_train, y_train = X, y
        X_test, y_test = X.iloc[0:0], y.iloc[0:0]

    # The baseline is computed on the *training* split and applied to the
    # hold-out, which is what a deployed constant predictor would actually do.
    baseline_class = y_train.value_counts().idxmax()
    baseline_accuracy = (
        float((y_test == baseline_class).mean()) if len(y_test)
        else float(y_train.value_counts(normalize=True).max())
    )

    # ---- 4. Compare and select ------------------------------------------- #
    models = get_candidate_models(n_classes=y.nunique())
    if only_models:
        unknown = set(only_models) - set(models)
        if unknown:
            logger.warning("Ignoring unknown model name(s): %s", sorted(unknown))
        models = {k: v for k, v in models.items() if k in only_models}
        if not models:
            raise DatasetError(f"No usable models left after filtering by {only_models}.")

    # XGBoost needs integer targets; a shared LabelEncoder keeps every candidate
    # interchangeable without special-casing the pipeline.
    label_encoder = LabelEncoder().fit(y)
    y_train_encoded = label_encoder.transform(y_train)

    comparison = compare_models(X_train, y_train_encoded, models, categorical, numeric)
    best_name = select_best(comparison)

    pipeline = build_pipeline(models[best_name], categorical, numeric)
    # ``LabelEncoder.transform`` is typed as ``ArrayLike``; materialise it as
    # a concrete integer array for sklearn's estimator ``fit`` signature.
    pipeline.fit(X_train, np.asarray(y_train_encoded, dtype=int))

    # ---- 5. Evaluate ----------------------------------------------------- #
    holdout_metrics = None
    if len(X_test):
        y_pred = label_encoder.inverse_transform(pipeline.predict(X_test))
        holdout_metrics = save_reports(
            y_test.tolist(), list(y_pred), prefix="holdout",
            baseline_accuracy=baseline_accuracy,
            extra={
                "model_name": best_name,
                "trained_at": timestamp(),
                "features": categorical + numeric,
                "baseline_class": str(baseline_class),
            },
        )

    importances = feature_importances(pipeline)
    if importances:
        save_json(importances, config.REPORTS_DIR / "feature_importances.json")
        logger.info(
            "Top features: %s",
            ", ".join(f"{k} {v:.3f}" for k, v in list(importances.items())[:6]),
        )

    # ---- 6. Persist ------------------------------------------------------ #
    beats_baseline = bool(holdout_metrics and holdout_metrics["beats_baseline"])
    should_save = force or beats_baseline or not config.BLOCK_SAVE_ON_NO_LIFT

    archived_to = archive_current_model() if (archive and should_save) else None
    if should_save:
        save_joblib(
            {"pipeline": pipeline, "label_encoder": label_encoder,
             "features": categorical + numeric},
            config.MODEL_PATH,
        )
    else:
        logger.error(
            "Model NOT saved: it does not beat the majority baseline and "
            "BLOCK_SAVE_ON_NO_LIFT is set. Pass --force to override."
        )

    metadata = {
        "model_name": best_name,
        "saved": should_save,
        "trained_at": timestamp(),
        "dataset": str(data_path or config.TRAINING_DATASET),
        "n_rows": int(len(frame)),
        "n_train": int(len(X_train)),
        "n_holdout": int(len(X_test)),
        "features": {"categorical": categorical, "numeric": numeric},
        "uses_asset_attributes": bool(extras),
        "classes": list(label_encoder.classes_),
        "class_distribution": y.value_counts().to_dict(),
        "majority_baseline_class": str(baseline_class),
        "signal_analysis": signal,
        "selection_metric": config.SELECTION_METRIC,
        "model_comparison": comparison,
        "holdout_metrics": holdout_metrics,
        "feature_importances": importances,
        "archived_previous_to": str(archived_to) if archived_to else None,
        "versions": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "scikit_learn": sklearn.__version__,
            "numpy": np.__version__,
            "xgboost_available": XGBOOST_AVAILABLE,
        },
    }
    save_json(metadata, config.METADATA_PATH)
    save_json(comparison, config.REPORTS_DIR / "model_comparison.json")

    logger.info("Training complete. Artefacts in %s", config.MODELS_DIR)
    if holdout_metrics and not beats_baseline:
        logger.warning(
            "Summary: accuracy %.4f against a %.4f baseline (lift %+.4f). This "
            "model is a constant with extra steps. Set ASSET_IMPACT_STRATEGY=rules "
            "or add asset attributes before wiring it into production.",
            holdout_metrics["accuracy"], holdout_metrics["majority_baseline_accuracy"],
            holdout_metrics["lift_over_baseline"],
        )
    return metadata


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def _main() -> None:
    parser = argparse.ArgumentParser(
        description="Train the asset-impact classifier.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--test-size", type=float, default=config.TEST_SIZE)
    parser.add_argument("--no-archive", action="store_true")
    parser.add_argument("--models", nargs="+", default=None, metavar="NAME")
    parser.add_argument("--force", action="store_true",
                        help="Train and save even if the features carry no signal.")
    args = parser.parse_args()

    try:
        train(args.data, test_size=args.test_size, archive=not args.no_archive,
              only_models=args.models, force=args.force)
    except Exception as exc:
        logger.error("Training failed: %s", exc)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    _main()
