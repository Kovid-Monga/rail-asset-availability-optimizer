"""
tests/test_dataset_and_predict.py
=================================
Tests for dataset assembly and the asset-impact prediction API.

Why these tests matter
----------------------
The one that earns its place most is
``test_duplicate_feature_rows_are_kept_by_default``. Deduplicating on the
modelled columns felt like sensible hygiene while writing ``build_dataset.py``
and it collapsed 5000 rows to 36, because with two categorical features there
are only 36 possible combinations and the repeat counts *are* the conditional
distribution. That is a silent, total loss of signal, so it is pinned here.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pandas as pd

from src import build_dataset, config
from src.predict import predict_asset_impact, predict_asset_impact_batch
from src.utils import AssetImpactError, DatasetError, ValidationError


def _expect_raises(exc_type, fn, *args, **kwargs):
    try:
        fn(*args, **kwargs)
    except exc_type:
        return
    raise AssertionError(f"Expected {exc_type.__name__}")


def _write_csv(frame: pd.DataFrame, name: str = "data.csv") -> Path:
    path = Path(tempfile.mkdtemp()) / name
    frame.to_csv(path, index=False)
    return path


def _priority_style_frame(n: int = 200) -> pd.DataFrame:
    import numpy as np

    rng = np.random.default_rng(0)
    return pd.DataFrame({
        config.TARGET_COLUMN: rng.choice(config.ASSET_IMPACT_LEVELS, n),
        config.SEVERITY_COLUMN: rng.choice(config.SEVERITY_LEVELS, n),
        config.TRAFFIC_COLUMN: rng.choice(config.TRAFFIC_LEVELS, n),
        "due_date_bucket": "3-7 days",
        "priority_score": 60,
    })


# --------------------------------------------------------------------------- #
# Dataset assembly
# --------------------------------------------------------------------------- #
def test_priority_history_yields_the_modelled_columns():
    path = _write_csv(_priority_style_frame())
    frame = build_dataset.from_priority_history(path)
    for column in (config.TARGET_COLUMN, config.SEVERITY_COLUMN, config.TRAFFIC_COLUMN):
        assert column in frame.columns
    assert (frame["severity_origin"] == "stored_label").all()


def test_duplicate_feature_rows_are_kept_by_default():
    """
    Repeat counts carry P(asset_impact | severity, traffic). Dropping them
    turns 5000 rows into 36 and destroys the only thing the model learns from.
    """
    path = _write_csv(_priority_style_frame(500))
    frame = build_dataset.build(priority_data=path, output=_write_csv(
        pd.DataFrame({"x": [1]}), "out.csv"))
    assert len(frame) == 500
    combinations = frame[config.BASE_FEATURES].drop_duplicates().shape[0]
    assert combinations <= 12  # 4 severities x 3 traffic levels
    assert len(frame) > combinations  # repeats survived


def test_dedup_flag_removes_exact_duplicate_records():
    frame = pd.concat([_priority_style_frame(50)] * 2, ignore_index=True)
    path = _write_csv(frame)
    out = build_dataset.build(
        priority_data=path, dedup=True,
        output=_write_csv(pd.DataFrame({"x": [1]}), "out2.csv"),
    )
    assert len(out) < len(frame)


def test_asset_attribute_columns_are_carried_through():
    frame = _priority_style_frame(100)
    frame["asset_type"] = "Bridge"
    frame["has_redundancy"] = "No"
    path = _write_csv(frame)
    out = build_dataset.from_priority_history(path)
    assert "asset_type" in out.columns
    assert "has_redundancy" in out.columns


def test_missing_required_columns_raise_with_a_useful_message():
    path = _write_csv(pd.DataFrame({config.TARGET_COLUMN: ["High"]}))
    try:
        build_dataset.from_priority_history(path)
    except DatasetError as exc:
        assert config.TRAFFIC_COLUMN in str(exc)
        return
    raise AssertionError("Expected DatasetError")


def test_building_with_no_source_is_rejected():
    _expect_raises(DatasetError, build_dataset.build)


def test_label_casing_is_normalised():
    frame = _priority_style_frame(30)
    frame[config.TARGET_COLUMN] = "high"
    frame[config.TRAFFIC_COLUMN] = " MEDIUM "
    path = _write_csv(frame)
    out = build_dataset.build(
        priority_data=path, output=_write_csv(pd.DataFrame({"x": [1]}), "out3.csv")
    )
    assert set(out[config.TARGET_COLUMN]) == {"High"}
    assert set(out[config.TRAFFIC_COLUMN]) == {"Medium"}


# --------------------------------------------------------------------------- #
# Demo data generator
# --------------------------------------------------------------------------- #
def test_demo_data_carries_asset_attributes_and_real_signal():
    frame = build_dataset.generate_demo_dataset(1500)
    for column in config.OPTIONAL_ASSET_FEATURES:
        assert column in frame.columns
    assert set(frame[config.TARGET_COLUMN]) == set(config.ASSET_IMPACT_LEVELS)


def test_demo_generation_is_reproducible():
    assert build_dataset.generate_demo_dataset(200, seed=5).equals(
        build_dataset.generate_demo_dataset(200, seed=5)
    )


# --------------------------------------------------------------------------- #
# Prediction: the rules strategy always works, with or without a trained model
# --------------------------------------------------------------------------- #
def test_rules_strategy_returns_the_documented_shape():
    result = predict_asset_impact("Critical", "High", strategy="rules")
    assert set(result) == {"asset_impact", "confidence", "source"}
    assert result["asset_impact"] in config.ASSET_IMPACT_LEVELS
    assert result["source"] == "rules"
    assert type(result["asset_impact"]) is str


def test_rules_cover_every_severity_and_traffic_combination():
    for severity in config.SEVERITY_LEVELS:
        for traffic in config.TRAFFIC_LEVELS:
            result = predict_asset_impact(severity, traffic, strategy="rules")
            assert result["asset_impact"] in config.ASSET_IMPACT_LEVELS


def test_rules_are_monotonic_in_severity_at_fixed_traffic():
    """Impact must never *decrease* as severity rises — an obvious sanity check."""
    order = {"Low": 0, "Medium": 1, "High": 2}
    for traffic in config.TRAFFIC_LEVELS:
        values = [
            order[predict_asset_impact(s, traffic, strategy="rules")["asset_impact"]]
            for s in ["Minor", "Moderate", "Major", "Critical"]
        ]
        assert values == sorted(values), f"non-monotonic at traffic={traffic}: {values}"


def test_inputs_are_case_insensitive():
    assert (
        predict_asset_impact("critical", "  HIGH ", strategy="rules")["asset_impact"]
        == predict_asset_impact("Critical", "High", strategy="rules")["asset_impact"]
    )


def test_invalid_inputs_are_rejected():
    _expect_raises(ValidationError, predict_asset_impact, "Catastrophic", "High",
                   strategy="rules")
    _expect_raises(ValidationError, predict_asset_impact, "Critical", "Extreme",
                   strategy="rules")
    _expect_raises(ValidationError, predict_asset_impact, None, "High", strategy="rules")


def test_an_invalid_strategy_is_rejected():
    _expect_raises(ValidationError, predict_asset_impact, "Critical", "High",
                   strategy="magic")


def test_details_mode_adds_diagnostics():
    result = predict_asset_impact("Major", "Medium", strategy="rules", return_details=True)
    assert result["strategy"] == "rules"
    assert config.SEVERITY_COLUMN in result["features_supplied"]


def test_batch_prediction_survives_a_bad_row():
    results = predict_asset_impact_batch(
        [
            {"severity": "Critical", "traffic": "High"},
            {"severity": "Nonsense", "traffic": "High"},
        ],
        strategy="rules",
    )
    assert results[0]["asset_impact"] in config.ASSET_IMPACT_LEVELS
    assert results[1]["error_type"] == "ValidationError"


def test_model_strategy_is_json_serialisable_when_a_model_exists():
    import json

    from src.predict import is_available

    if not is_available():
        print("      (skipped: no trained model — run `python -m src.train`)")
        return
    result = predict_asset_impact("Critical", "High", strategy="model")
    assert type(result["asset_impact"]) is str
    assert result["confidence"] is None or type(result["confidence"]) is float
    json.dumps(result)


def test_exceptions_carry_http_statuses():
    try:
        predict_asset_impact("bad", "High", strategy="rules")
    except AssetImpactError as exc:
        assert exc.http_status == 400
        return
    raise AssertionError("Expected an error")


if __name__ == "__main__":
    import sys

    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
    from _runner import run_module

    raise SystemExit(run_module(sys.modules[__name__]))
