# Asset Impact Model (stage 3)

Sits between the Maintenance-Severity-Model and the Priority-Model, so
`asset_impact` no longer has to be typed in by hand.

```
raw request
    │
    ├─ reason_description ──▶ [1] Maintenance-Severity-Model ──▶ severity
    │                                                              │
    ├─ traffic ────────────────────────┬──────────────────────────┘
    │   (+ asset attributes, if any) ──┤
    │                                  ▼
    │                        [2] Asset-Impact-Model ──▶ asset_impact
    │                                  │
    └─ due_date ───────────────────┬───┘
                                   ▼
                         [3] Priority-Model ──▶ priority_score, priority_class
```

```python
from src.pipeline import score_request

score_request(
    reason_description="Track fracture detected near station",
    traffic="High",
    due_date="2026-09-25",
)
# {"predicted_severity": "Critical", "asset_impact": "High",
#  "priority_score": 93, "priority_class": "Critical", "trace": {...}}
```

The Priority-Model is untouched. It still receives `asset_impact` as a plain
input feature — the value just arrives from stage 2 now instead of a form field.

---

## Read this first: what your data says

I ran the analysis on the `priority_training_data.csv` you attached before
building anything. The result changes what I would recommend, so here it is up
front.

**Severity and traffic carry no information about asset impact in your data.**

| Feature | Cramér's V | χ² p-value | Mutual information |
|---|---|---|---|
| `reason_severity` | 0.0175 | 0.80 | 0.0004 bits |
| `traffic` | 0.0171 | 0.57 | 0.0004 bits |

Cramér's V below 0.1 is conventionally negligible; these are near zero, and the
p-values say the association is statistically indistinguishable from none at
all. The decisive number:

```
majority-class baseline accuracy   0.4482   (always answer "Medium")
best possible classifier           0.4482   (any model, any tuning)
maximum achievable lift           +0.0000
```

The ceiling is what the *optimal* classifier scores — predicting the most common
`asset_impact` within each `(severity, traffic)` cell. No algorithm can beat it.
It equals the baseline exactly, so nothing learnable is there.

Training anyway confirms it. The pipeline compared logistic regression, a
decision tree, random forest and XGBoost; the winner scored **0.3220** on the
hold-out against a 0.4480 baseline — **worse than a constant** — with a Cohen's
kappa of **-0.0098**, meaning agreement no better than chance. It scores below
the baseline rather than matching it because `class_weight="balanced"` makes it
spread guesses across all three classes instead of parking on "Medium".

One caveat I should state plainly: this dataset was generated, and the four
factors were sampled independently when it was made. So the zero association is
partly an artifact of how the file was produced, and real recorded data may well
show more. But there is a second problem that no amount of real data fixes.

### The structural problem

If `asset_impact = g(severity, traffic)`, then the priority score becomes:

```
priority = f( g(severity, traffic), severity, traffic, due_date )
```

`asset_impact` contributes **no new information** to the score. It is a
deterministic function of two things the Priority-Model already has. The 30
points allocated to asset impact would silently become extra weight on severity
and traffic — you would be double-counting them and calling the result a third
factor.

Your own specification says what asset impact is meant to capture:
*"maintenance significantly affects the availability/functionality of the
asset."* That is a property of **the asset**: does it have redundancy, is it on
a single-line section, is there a diversion route, is it a trunk route or a
yard siding. None of that is recoverable from the text of the remark or the
traffic level.

### What works instead

The project is built so this is a data change, not a code change. Add asset
attributes to the dataset and they join the feature set automatically. Here is
the same pipeline on an illustrative dataset where impact depends on asset
attributes (`python -m src.build_dataset --demo`):

```
ceiling accuracy:  baseline 0.3700 | severity+traffic 0.3970 | +asset attributes 0.8615
```

Severity and traffic add 2.7 points over a constant. Asset attributes add 46.
The trained model reaches **0.7750** accuracy, lift **+0.4050**, kappa **0.6620**
— and the feature importances are unambiguous:

```
has_redundancy_Yes   1.725
has_redundancy_No    1.621
line_type_Single     1.364
asset_type_Bridge    1.234
```

Redundancy alone tells you more about asset impact than severity and traffic
combined. That is the model you want.

### What I shipped as the default, and why

`config.STRATEGY` ships as **`"rules"`**, not `"model"` — a deliberate
departure from your brief that you should feel free to reverse.

`asset_impact` is worth up to 30 of the 100 priority points. Wiring a
near-random value into that would quietly corrupt every score in the system,
and it would look like it was working. Until the signal analysis reports
`usable`, `config.RULES_MATRIX` gives a documented severity × traffic → impact
table your engineers can read, argue with and correct. It is not better
*information* than the model — it has the same double-counting problem — but it
is honest, stable, reviewable, and it keeps the manual workflow's intent intact.

Flip it with one line in `config.py`, `ASSET_IMPACT_STRATEGY=model` in the
environment, or `strategy="model"` per call. The training pipeline, the model,
the metrics and the artefacts are all there and working — the switch is a
decision, not a build step.

---

## Quick start

```bash
cd Asset-Impact-Model
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export ASSET_IMPACT_SEVERITY_MODEL_PATH=/path/to/Maintenance-Severity-Model
export ASSET_IMPACT_PRIORITY_MODEL_PATH=/path/to/Priority-Model

# Deliverable 1 — build the training set
python -m src.build_dataset --priority-data ../Priority-Model/data/raw/priority_training_data.csv

# Check before you train
python -m src.diagnostics

# Deliverable 2 — train
python -m src.train

# Deliverable 3 — end-to-end
python -m src.pipeline --reason "Track fracture detected" --traffic High --due-date 2026-09-25

python tests/run_all.py     # 43 tests
```

---

## Project layout

```
Asset-Impact-Model/
├── data/
│   ├── raw/                              your source files
│   ├── asset_impact_training_data.csv    built by build_dataset.py
│   └── demo_with_asset_features.csv      illustrative, has real signal
├── models/    asset_impact_model.joblib, metadata.json, archive/<timestamp>/
├── logs/      app.log (rotating), predictions.jsonl (audit trail)
├── reports/   signal_analysis.json, holdout_*, feature_importances.json,
│              model_comparison.json, dataset_build.json
├── src/
│   ├── config.py           paths, features, rules matrix, integration settings
│   ├── utils.py            logging, typed exceptions, validation, persistence
│   ├── clients.py          the seam to both sibling projects
│   ├── diagnostics.py      signal analysis — the safeguard
│   ├── build_dataset.py    ── Deliverable 1
│   ├── train.py            ── Deliverable 2
│   ├── evaluate.py         metrics, confusion matrices, lift
│   ├── predict.py          predict_asset_impact()
│   └── pipeline.py         ── Deliverable 3
├── tests/     test_diagnostics.py, test_dataset_and_predict.py, test_pipeline.py
├── requirements.txt
└── README.md
```

### Why each file exists

**`config.py`** — the feature list here is the most important setting in the
project. `BASE_FEATURES` is the pair you asked for; `OPTIONAL_ASSET_FEATURES`
join the model automatically whenever the dataset supplies them. Adding
`has_redundancy` to your data is all it takes — no code edit, no retraining
script change.

**`diagnostics.py`** — runs before any model is fitted and answers "is there
anything here to learn?". It exists because a classifier trained on noise does
not fail: scikit-learn returns a fitted object, `predict` returns labels, and
the accuracy figure looks respectable because it quietly equals the
majority-class rate. Nothing in a standard pipeline complains. You find out in
production.

**`build_dataset.py` (Deliverable 1)** — assembles `(severity, traffic[, asset
attributes]) -> asset_impact` from priority history, raw remarks, or both, with
an optional asset-register join. Two decisions inside it are worth knowing
about, and they are covered below.

**`train.py` (Deliverable 2)** — signal analysis, then stratified CV across
logistic regression / decision tree / random forest / XGBoost, one-standard-error
tie-breaking toward the simplest model, hold-out evaluation **against the
majority baseline**, feature importances, archived previous model, joblib
artefact plus metadata.

**`evaluate.py`** — every report carries the baseline beside the model's score
and the lift between them, because on an imbalanced target accuracy alone is
close to meaningless. Also reports balanced accuracy and Cohen's kappa, both of
which expose a model that is riding the class prior.

**`clients.py`** — the only file that knows how the sibling projects are laid
out. All three use a package called `src`, so a plain
`import_module("src.predict")` returns *this* project's module and the failure
looks like a missing function rather than a name clash. `_import_isolated`
handles it.

**`predict.py`** — caches the pipeline in a module-level singleton, so a restart
loads it once and a long-running service pays the joblib cost once rather than
per request. `reload_pipeline()` picks up a retrain without a restart.

**`pipeline.py` (Deliverable 3)** — the only place that knows the three stages
exist in this order.

---

## Two decisions inside the dataset builder

**Duplicate feature rows are kept.** Deduplicating on the modelled columns felt
like sensible hygiene while writing this, and it collapsed your 5000 rows to
**36** — because with two categorical features there are only 4 × 3 × 3 = 36
possible combinations, and the *repeat counts are the conditional distribution*
the model learns from. Dropping them is a total, silent loss of signal. There is
a test pinning this. `--dedup` is available for sources that genuinely contain
repeated records of the same event.

**Severity is regenerated by the model, not read from a stored label.** When raw
text is available, `build_dataset.py` runs the severity model over it even if a
human severity label exists. At inference this model receives a
*model-predicted* severity; training it on *human-labelled* severity means the
production input distribution differs from the training one. That is train/serve
skew, and it degrades quietly — the model evaluates fine and drifts in
production. Where both exist, the disagreement rate is reported: if the severity
model disagrees with humans often, fix stage 1 before training stage 3 on its
output. `PREFER_MODEL_PREDICTED_SEVERITY = False` reverses this.

---

## Adding asset attributes

This is the change that makes the model worth having.

1. Build an asset register: one row per asset, keyed by `asset_id`.

   ```csv
   asset_id,asset_type,line_type,has_redundancy,section_criticality,asset_age_band
   TRK-4203,Track,Single,No,Trunk,Ageing
   SIG-1187,Signalling,Double,Yes,Branch,Mid-life
   ```

2. Make sure your maintenance records carry `asset_id`.

3. Join it in:

   ```bash
   python -m src.build_dataset \
       --priority-data ../Priority-Model/data/raw/priority_training_data.csv \
       --asset-register data/raw/assets.csv
   python -m src.diagnostics    # expect the verdict to move to "usable"
   python -m src.train
   ```

4. When the verdict reads `usable`, set `STRATEGY = "model"`.

Any column you add to `config.OPTIONAL_ASSET_FEATURES` is picked up
automatically. Numeric attributes (daily tonnage, age in years) go in
`OPTIONAL_NUMERIC_FEATURES` and get imputation and scaling.

Start with `has_redundancy` if you can only collect one field. In the
illustrative run it was the single strongest predictor by a wide margin, and it
is usually the easiest attribute to populate.

---

## The API

```python
from src.pipeline import score_request, score_requests, health
from src.predict import predict_asset_impact, reload_pipeline

# End to end
score_request(reason_description="Track fracture detected",
              traffic="High", due_date="2026-09-25")

# With asset attributes
score_request(reason_description="Loose fittings found", traffic="Low",
              due_date="2026-12-01",
              asset_features={"asset_type": "Bridge", "has_redundancy": "No",
                              "line_type": "Single", "section_criticality": "Trunk"},
              strategy="model")

# Manual override — an engineer's judgement always wins over the model
score_request(..., asset_impact="High")

# This stage alone
predict_asset_impact(severity="Critical", traffic="High")

health()   # readiness of all three stages
```

Every response carries a `trace` with each stage's value, source and confidence.
When someone disputes a priority you need to know whether the severity was
wrong, the asset impact was wrong, or the arithmetic was right and the rules are
wrong — three different fixes.

### CLI

```bash
python -m src.build_dataset --priority-data <csv> [--raw-remarks <csv>] [--asset-register <csv>]
python -m src.build_dataset --demo                  # illustrative dataset with signal
python -m src.diagnostics [--data <csv>]
python -m src.train [--data <csv>] [--models ...] [--force]
python -m src.evaluate --data <heldout.csv>
python -m src.predict --severity Critical --traffic High --details
python -m src.pipeline --reason "..." --traffic High --due-date 2026-09-25
python -m src.pipeline --input-csv requests.csv --output-csv scored.csv
python -m src.pipeline --health
```

### For the API layer

No web framework, on purpose. Every exception carries `.http_status`:

| Exception | HTTP | Cause |
|---|---|---|
| `ValidationError` | 400 | Bad input |
| `UpstreamModelUnavailableError` | 503 | A sibling model is unreachable |
| `ModelNotTrainedError` | 500 | `strategy="model"` with no artefact |
| `DatasetError` | 500 | Malformed training data |
| `InsufficientSignalError` | 500 | Features carry no information |

Responses are plain `str`/`int`/`float`, tested for `json.dumps`. `health()`
gives you a readiness endpoint that reports each stage separately.

---

## Results summary

**On your data** (severity + traffic only):

| | |
|---|---|
| Ceiling / baseline | 0.4482 / 0.4482 (lift **+0.0000**) |
| Selected model | logistic regression |
| Hold-out accuracy | 0.3220 (**−0.1260** vs baseline) |
| Cohen's kappa | −0.0098 |
| Verdict | **no_signal** |

**On the illustrative data** (with asset attributes):

| | |
|---|---|
| Ceiling / baseline | 0.8615 / 0.3700 (lift **+0.4915**) |
| Selected model | logistic regression |
| Hold-out accuracy | 0.7750 (**+0.4050** vs baseline) |
| Cohen's kappa | 0.6620 |
| Verdict | **usable** |

Same code, same pipeline. The difference is entirely the features.

---

## Honest limitations

**The illustrative dataset is illustrative.** It demonstrates that the training
code works when features carry signal, and it models the relationship I would
expect. It is not evidence about your railway and must never be trained on for
production use.

**The rules matrix has the same double-counting problem as a severity+traffic
model.** It is not better information — it is more honest about being a
convention, and it is editable by people who know the assets. Both are
placeholders until asset attributes exist.

**Errors compound across three stages.** A wrong severity produces a wrong asset
impact and a wrong priority, and the score moves by up to 20 points from the
severity error plus 20 more from the asset-impact error — easily enough to cross
two band boundaries. Stage 1's confidence is uncalibrated and it was trained on
a synthetic sample. The `trace` surfaces every confidence; route low-confidence
requests to a human.

**The severity → asset impact link is only as good as stage 1.** Once stage 3
trains on stage 1's output, stage 1's errors become stage 3's training labels.
`build_dataset.py` reports the disagreement rate wherever human labels exist —
watch it.

**A model that predicts a feature of another model is a maintenance burden.**
Three models in a chain means three retraining schedules, three drift profiles
and three sets of artefacts to keep in sync. That is worth it when the middle
model adds information. Make sure it does before you commit to running it.
