from src.predict import predict_asset_impact
result = predict_asset_impact(
    severity="critical",
    traffic="Low",
    strategy="rules",
    return_details=True,
)
print(result)