"""
src package
===========
Makes ``src`` importable as a package so ``from src import config`` and
``python -m src.train`` work from any directory.

Public surface:

    from src.pipeline import score_request          # end-to-end (Deliverable 3)
    from src.predict import predict_asset_impact    # this stage only
    from src.build_dataset import build             # dataset assembly (Deliverable 1)
    from src.train import train                     # retraining (Deliverable 2)
"""

__version__ = "1.0.0"

__all__ = ["__version__"]
