"""
diagnostics.py
==============
Measures whether the chosen features carry usable information about
``asset_impact``, *before* a model is trained on them.

Why this file exists
--------------------
A classifier will always train. Given features that are pure noise, scikit-learn
returns a fitted object, ``predict`` returns labels, and the accuracy figure
looks respectable because it quietly equals the majority-class rate. Nothing in
a standard pipeline complains. You find out in production, when every request
comes back "Medium".

So this module runs first and reports four things:

``cramers_v``
    Effect size of the association between each feature and the target. Below
    0.1 is conventionally negligible.

``chi_square_p``
    Whether any association at all is statistically distinguishable from zero.

``mutual_information``
    How many bits each feature tells you about the target. Zero means none.

``ceiling_accuracy``
    The headline number. For categorical features the best achievable
    classifier predicts the most common target value within each feature
    combination — no model can beat that. Comparing it to the majority-class
    baseline gives the *maximum possible lift* from these features. If the
    ceiling equals the baseline, no algorithm and no amount of tuning will
    help, and the honest answer is different features rather than a better
    model.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency
from sklearn.metrics import accuracy_score
from sklearn.metrics import mutual_info_score

from src import config
from src.utils import get_logger

logger = get_logger(__name__)


def cramers_v(x: pd.Series, y: pd.Series) -> tuple[float, float]:
    """
    Cramer's V and the chi-square p-value for two categorical series.

    V is normalised to 0-1 so it is comparable across features with different
    numbers of levels, which raw chi-square is not.
    """
    table = pd.crosstab(x, y)
    if table.shape[0] < 2 or table.shape[1] < 2:
        return 0.0, 1.0
    chi2, p_value, _, _ = chi2_contingency(table)
    n = table.to_numpy().sum()
    denominator = min(table.shape[0] - 1, table.shape[1] - 1)
    return float(np.sqrt((chi2 / n) / denominator)), float(p_value)


def ceiling_accuracy(frame: pd.DataFrame, features: list[str], target: str) -> float:
    """
    Accuracy of the best possible classifier on these features.

    Within each distinct feature combination the optimal prediction is the most
    frequent target value. This is the Bayes-optimal rule for discrete features
    and an upper bound no model can exceed.
    """
    if not features:
        return float(frame[target].value_counts(normalize=True).max())
    lookup = frame.groupby(features, observed=True)[target].agg(
        lambda s: s.mode().iloc[0]
    )
    predicted = frame.set_index(features).index.map(lookup)
    return float(accuracy_score(frame[target], predicted))


def majority_baseline(frame: pd.DataFrame, target: str) -> tuple[float, str]:
    """Accuracy of always predicting the single most common class, and that class."""
    counts = frame[target].value_counts(normalize=True)
    return float(counts.max()), str(counts.idxmax())


def analyse(
    frame: pd.DataFrame,
    features: list[str] | None = None,
    target: str = config.TARGET_COLUMN,
) -> dict[str, Any]:
    """
    Run the full signal analysis and return a verdict.

    The ``verdict`` field is one of:

    ``"usable"``
        The features beat the majority baseline by more than
        ``config.MIN_LIFT_OVER_BASELINE``. Train the model.
    ``"weak"``
        Some lift, but marginal. Train it, watch it, and consider more features.
    ``"no_signal"``
        The ceiling equals the baseline. A model here is a constant with extra
        steps; the fix is different features, not a different algorithm.
    """
    if features is None:
        features, _ = config.active_features(frame.columns)

    baseline, majority_class = majority_baseline(frame, target)
    ceiling = ceiling_accuracy(frame, features, target)
    lift = ceiling - baseline

    per_feature: dict[str, Any] = {}
    for feature in features:
        v, p_value = cramers_v(frame[feature], frame[target])
        mi = float(mutual_info_score(frame[feature], frame[target]))
        per_feature[feature] = {
            "cramers_v": round(v, 4),
            "chi_square_p": round(p_value, 4),
            "mutual_information_bits": round(mi / np.log(2), 6),
            "n_levels": int(frame[feature].nunique()),
            "negligible": bool(v < config.MIN_CRAMERS_V),
        }

    if lift < config.MIN_LIFT_OVER_BASELINE:
        verdict = "no_signal"
    elif lift < 2 * config.MIN_LIFT_OVER_BASELINE:
        verdict = "weak"
    else:
        verdict = "usable"

    result = {
        "n_rows": int(len(frame)),
        "target": target,
        "features": features,
        "target_distribution": frame[target].value_counts().to_dict(),
        "majority_class": majority_class,
        "majority_baseline_accuracy": round(baseline, 4),
        "ceiling_accuracy": round(ceiling, 4),
        "max_possible_lift": round(lift, 4),
        "per_feature": per_feature,
        "verdict": verdict,
    }

    _log_verdict(result)
    return result


def _log_verdict(result: dict[str, Any]) -> None:
    """Report the analysis at a log level that matches how bad the news is."""
    logger.info(
        "Signal analysis on %d rows — majority baseline %.4f, ceiling %.4f, "
        "max possible lift %+.4f.",
        result["n_rows"], result["majority_baseline_accuracy"],
        result["ceiling_accuracy"], result["max_possible_lift"],
    )
    for feature, stats in result["per_feature"].items():
        logger.info(
            "  %-22s Cramer's V %.4f (p = %.3f), %.4f bits%s",
            feature, stats["cramers_v"], stats["chi_square_p"],
            stats["mutual_information_bits"],
            "  <- negligible" if stats["negligible"] else "",
        )

    if result["verdict"] == "no_signal":
        logger.warning(
            "VERDICT: no signal. The best possible classifier on %s scores "
            "%.4f, which is what you get by always answering '%s'. No "
            "algorithm can beat this ceiling — the fix is different features, "
            "not a different model. See the README section on asset "
            "attributes.",
            result["features"], result["ceiling_accuracy"], result["majority_class"],
        )
    elif result["verdict"] == "weak":
        logger.warning(
            "VERDICT: weak signal (+%.4f over baseline). Trainable, but keep "
            "an eye on per-class recall and consider adding asset attributes.",
            result["max_possible_lift"],
        )
    else:
        logger.info(
            "VERDICT: usable signal (+%.4f over baseline).", result["max_possible_lift"]
        )


def compare_feature_sets(
    frame: pd.DataFrame, target: str = config.TARGET_COLUMN
) -> dict[str, Any]:
    """
    Ceiling accuracy for the base features alone versus with asset attributes.

    This is the number that settles the design question. If adding asset
    attributes lifts the ceiling substantially, they are what the model needs
    and severity plus traffic were never going to be enough.
    """
    base = [f for f in config.BASE_FEATURES if f in frame.columns]
    extras = [f for f in config.OPTIONAL_ASSET_FEATURES if f in frame.columns]
    baseline, majority_class = majority_baseline(frame, target)

    comparison = {
        "majority_baseline": round(baseline, 4),
        "majority_class": majority_class,
        "base_features": base,
        "base_ceiling": round(ceiling_accuracy(frame, base, target), 4),
        "asset_features_available": extras,
    }

    if extras:
        comparison["with_asset_features"] = base + extras
        comparison["combined_ceiling"] = round(
            ceiling_accuracy(frame, base + extras, target), 4
        )
        comparison["asset_features_only_ceiling"] = round(
            ceiling_accuracy(frame, extras, target), 4
        )
        comparison["gain_from_asset_features"] = round(
            comparison["combined_ceiling"] - comparison["base_ceiling"], 4
        )
        logger.info(
            "Ceiling accuracy: baseline %.4f | severity+traffic %.4f | "
            "+asset attributes %.4f (gain %+.4f)",
            baseline, comparison["base_ceiling"], comparison["combined_ceiling"],
            comparison["gain_from_asset_features"],
        )
    else:
        logger.info(
            "No asset-attribute columns in this dataset, so only "
            "severity+traffic could be evaluated (ceiling %.4f vs baseline %.4f).",
            comparison["base_ceiling"], baseline,
        )

    return comparison


def _main() -> None:
    import argparse
    from pathlib import Path

    from src.utils import save_json

    parser = argparse.ArgumentParser(
        description="Check whether the features predict asset_impact at all."
    )
    parser.add_argument("--data", type=Path, default=config.TRAINING_DATASET)
    args = parser.parse_args()

    frame = pd.read_csv(args.data)
    result = analyse(frame)
    result["feature_set_comparison"] = compare_feature_sets(frame)
    save_json(result, config.REPORTS_DIR / "signal_analysis.json")
    print(f"\nVerdict: {result['verdict']}")
    print(f"Report written to {config.REPORTS_DIR / 'signal_analysis.json'}")


if __name__ == "__main__":
    _main()
