"""
predict.py
==========
Inference for the asset-impact model.

    from src.predict import predict_asset_impact

    predict_asset_impact(severity="Critical", traffic="High")
    # {"asset_impact": "High", "confidence": 0.72, "source": "model"}

Why this file exists
--------------------
The pipeline is cached in a module-level singleton, so a restart loads it from
disk once and a long-running service pays the joblib cost once rather than per
request. ``reload_pipeline()`` picks up a retrain without a restart.

Two strategies
--------------
``STRATEGY = "model"`` uses the trained classifier. ``STRATEGY = "rules"`` uses
the editable matrix in ``config.RULES_MATRIX``. The rules path exists because
when the signal analysis says the features carry no information, a table your
engineers can read and correct is more honest and more useful than a model that
has learned the class prior. It also means the pipeline keeps working before
the first model is trained.

Extra features are passed through as keyword arguments. If the loaded model was
trained with asset attributes, supply them; if one is missing the model still
predicts (the encoder handles unknowns), but a warning is logged, because a
silently degraded prediction is worse than a loud one.
"""

from __future__ import annotations

import argparse
import json
from typing import Any

import numpy as np
import pandas as pd

from src import config
from src.utils import (
    AssetImpactError,
    ModelNotTrainedError,
    ValidationError,
    audit_log,
    get_logger,
    load_joblib,
    load_json,
    validate_choice,
)

logger = get_logger(__name__)

_BUNDLE: dict[str, Any] | None = None
_METADATA: dict[str, Any] | None = None


# --------------------------------------------------------------------------- #
# Model loading
# --------------------------------------------------------------------------- #
def _load_bundle(reload: bool = False) -> dict[str, Any]:
    global _BUNDLE, _METADATA
    if _BUNDLE is None or reload:
        bundle = load_joblib(config.MODEL_PATH)
        if not isinstance(bundle, dict) or "pipeline" not in bundle:
            raise AssetImpactError(
                f"{config.MODEL_PATH} is not in the expected format. Retrain with "
                f"`python -m src.train`."
            )
        _BUNDLE = bundle
        try:
            _METADATA = load_json(config.METADATA_PATH)
        except Exception:
            _METADATA = {}
        logger.info(
            "Loaded the asset-impact model (%s, trained %s, features %s).",
            (_METADATA or {}).get("model_name", "unknown"),
            (_METADATA or {}).get("trained_at", "unknown date"),
            bundle.get("features"),
        )
    return _BUNDLE


def get_pipeline(reload: bool = False):
    """The fitted sklearn Pipeline, loaded on first use."""
    return _load_bundle(reload)["pipeline"]


def reload_pipeline() -> None:
    """Drop the cache so the next call re-reads from disk."""
    _load_bundle(reload=True)


def get_metadata() -> dict[str, Any]:
    """Training metadata for the loaded model — useful for ``/health``."""
    _load_bundle()
    return dict(_METADATA or {})


def is_available() -> bool:
    """True if a trained model can be loaded. Never raises."""
    try:
        _load_bundle()
        return True
    except (ModelNotTrainedError, AssetImpactError):
        return False


# --------------------------------------------------------------------------- #
# Strategies
# --------------------------------------------------------------------------- #
def _predict_by_rules(severity: str, traffic: str) -> dict[str, Any]:
    """Look the answer up in the editable matrix. Always available."""
    try:
        impact = config.RULES_MATRIX[severity][traffic]
    except KeyError as exc:
        raise ValidationError(
            f"No rule for severity={severity!r}, traffic={traffic!r}. "
            f"Check config.RULES_MATRIX."
        ) from exc
    return {"asset_impact": impact, "confidence": None, "source": "rules"}


def _predict_by_model(features: dict[str, Any]) -> dict[str, Any]:
    """Run one row through the trained pipeline."""
    bundle = _load_bundle()
    pipeline = bundle["pipeline"]
    label_encoder = bundle["label_encoder"]
    expected = bundle.get("features", list(features))

    missing = [f for f in expected if f not in features or features[f] is None]
    if missing:
        logger.warning(
            "Predicting without %s — the model was trained with these features, "
            "so this prediction is less reliable than it looks.", missing,
        )

    row = {f: features.get(f) for f in expected}
    frame = pd.DataFrame([row], columns=expected)

    encoded = pipeline.predict(frame)[0]
    impact = str(label_encoder.inverse_transform([encoded])[0])

    confidence = None
    probabilities = None
    if hasattr(pipeline, "predict_proba"):
        proba = np.asarray(pipeline.predict_proba(frame))[0]
        confidence = round(float(proba.max()), 4)
        probabilities = {
            str(cls): round(float(p), 4)
            for cls, p in sorted(
                zip(label_encoder.inverse_transform(np.arange(len(proba))), proba),
                key=lambda kv: -kv[1],
            )
        }

    return {
        "asset_impact": impact,
        "confidence": confidence,
        "source": "model",
        "probabilities": probabilities,
    }


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #
def predict_asset_impact(
    severity: str,
    traffic: str,
    *,
    strategy: str | None = None,
    return_details: bool = False,
    **asset_features: Any,
) -> dict[str, Any]:
    """
    Predict asset impact from severity, traffic and any available asset attributes.

    Parameters
    ----------
    severity
        ``"Critical" | "Major" | "Moderate" | "Minor"``, any casing. Normally
        the output of the Maintenance-Severity-Model.
    traffic
        ``"High" | "Medium" | "Low"``, any casing. From COA data.
    strategy
        ``"model"`` or ``"rules"``; overrides ``config.STRATEGY`` for this call.
    return_details
        Add the probability distribution, the features used and a low-confidence
        flag.
    **asset_features
        Optional asset attributes (``asset_type``, ``line_type``,
        ``has_redundancy``, ...). Supplied only if the loaded model was trained
        with them.

    Returns
    -------
    dict
        ``{"asset_impact": str, "confidence": float | None, "source": str}``.

    Raises
    ------
    ValidationError
        Bad input (HTTP 400).
    ModelNotTrainedError
        ``strategy="model"`` with no trained artefact (HTTP 500).
    """
    mode = (strategy or config.STRATEGY).strip().lower()
    if mode not in {"model", "rules"}:
        raise ValidationError(f"strategy must be 'model' or 'rules', got {mode!r}.")

    severity = validate_choice(severity, config.SEVERITY_LEVELS, "severity")
    traffic = validate_choice(traffic, config.TRAFFIC_LEVELS, "traffic")

    if mode == "rules":
        result = _predict_by_rules(severity, traffic)
    else:
        features = {
            config.SEVERITY_COLUMN: severity,
            config.TRAFFIC_COLUMN: traffic,
            **{k: v for k, v in asset_features.items() if v is not None},
        }
        result = _predict_by_model(features)

    low_confidence = (
        result["confidence"] is not None
        and result["confidence"] < config.LOW_CONFIDENCE_THRESHOLD
    )

    response = {
        "asset_impact": result["asset_impact"],
        "confidence": result["confidence"],
        "source": result["source"],
    }
    if return_details:
        response["probabilities"] = result.get("probabilities")
        response["low_confidence"] = low_confidence
        response["strategy"] = mode
        response["features_supplied"] = sorted(
            [config.SEVERITY_COLUMN, config.TRAFFIC_COLUMN]
            + [k for k, v in asset_features.items() if v is not None]
        )
        if mode == "model":
            response["model_name"] = get_metadata().get("model_name")

    audit_log({
        "stage": "asset_impact",
        "severity": severity,
        "traffic": traffic,
        "asset_features": {k: v for k, v in asset_features.items() if v is not None},
        "strategy": mode,
        **response,
    })
    return response


def predict_asset_impact_batch(rows, *, strategy: str | None = None) -> list[dict]:
    """
    Score many rows. One bad row does not sink the batch.

    Failures come back as ``{"index": i, "error": ..., "error_type": ...}`` in
    the same position, so a backlog run returns everything that worked.
    """
    results = []
    for index, row in enumerate(rows):
        try:
            results.append(predict_asset_impact(**row, strategy=strategy))
        except AssetImpactError as exc:
            logger.error("Row %d failed: %s", index, exc)
            results.append({"index": index, "error": str(exc),
                            "error_type": type(exc).__name__})
    return results


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def _main() -> None:
    parser = argparse.ArgumentParser(
        description="Predict asset impact from severity and traffic.",
        epilog='Example: python -m src.predict --severity Critical --traffic High --details',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--severity", required=True)
    parser.add_argument("--traffic", required=True)
    parser.add_argument("--strategy", choices=["model", "rules"], default=None)
    parser.add_argument("--asset-type")
    parser.add_argument("--line-type")
    parser.add_argument("--has-redundancy")
    parser.add_argument("--section-criticality")
    parser.add_argument("--asset-age-band")
    parser.add_argument("--details", action="store_true")
    args = parser.parse_args()

    extras = {
        "asset_type": args.asset_type,
        "line_type": args.line_type,
        "has_redundancy": args.has_redundancy,
        "section_criticality": args.section_criticality,
        "asset_age_band": args.asset_age_band,
    }

    try:
        result = predict_asset_impact(
            severity=args.severity, traffic=args.traffic,
            strategy=args.strategy, return_details=args.details,
            **{k: v for k, v in extras.items() if v is not None},
        )
        print(json.dumps(result, indent=2, default=str))
    except AssetImpactError as exc:
        logger.error("%s: %s", type(exc).__name__, exc)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    _main()
