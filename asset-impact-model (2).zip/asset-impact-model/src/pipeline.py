"""
pipeline.py  —  Deliverable 3
=============================
End-to-end inference. One raw maintenance request in, a priority out, with
every intermediate value visible.

    raw request
        │
        ├─ reason_description ──▶ [1] Maintenance-Severity-Model ──▶ severity
        │                                                              │
        ├─ traffic ────────────────────────┬──────────────────────────┘
        │   (+ asset attributes, if any) ──┤
        │                                  ▼
        │                        [2] Asset-Impact-Model ──▶ asset_impact
        │                                  │
        └─ due_date ───────────────────┬───┘
                                       ▼
                             [3] Priority-Model ──▶ priority_score, priority_class

Usage::

    from src.pipeline import score_request

    score_request(
        reason_description="Track fracture detected near station",
        traffic="High",
        due_date="2026-09-25",
    )

Why this file exists
--------------------
It is the only place that knows the three stages exist in this order. Each
model stays independently trainable, testable and replaceable; the sequencing
lives here.

Two things it does that a naive chain would not:

**The severity is computed once.** Stage 3 needs it and so does stage 2's
priority calculation. Passing ``severity=`` into the Priority-Model rather than
the raw text means the NLP model runs once per request instead of twice, and
removes any chance of the asset impact and the priority score being derived
from two different severity values.

**The trace is returned, not just the answer.** Every intermediate value,
confidence and model name comes back under ``trace``. When someone disputes a
priority, you need to know whether the severity was wrong, the asset impact was
wrong, or the arithmetic was right and the rules are wrong — and that is three
different fixes.
"""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path
from typing import Any, Iterable, cast

from src import clients, config
from src.predict import predict_asset_impact
from src.utils import (
    AssetImpactError,
    ValidationError,
    audit_log,
    get_logger,
    validate_choice,
    validate_text,
)

logger = get_logger(__name__)


def score_request(
    reason_description: str | None = None,
    traffic: str = "Medium",
    due_date: str | date | None = None,
    *,
    severity: str | None = None,
    asset_impact: str | None = None,
    request_date: str | date | None = None,
    asset_features: dict[str, Any] | None = None,
    strategy: str | None = None,
    return_trace: bool = True,
) -> dict[str, Any]:
    """
    Run one maintenance request through all three models.

    Parameters
    ----------
    reason_description
        Free text. Classified by the severity model unless ``severity`` is given.
    traffic
        ``"High" | "Medium" | "Low"`` from COA data for the block section.
    due_date
        When the work is due. ISO ``YYYY-MM-DD`` preferred.
    severity
        Skip stage 1 with a known severity (human override, backfill, test).
    asset_impact
        Skip stage 2 with a known asset impact. This is the escape hatch that
        keeps the old manual workflow available: if an engineer wants to state
        the impact directly, their value wins and no model overrides it.
    request_date
        Date urgency is measured from. Defaults to today; pass it explicitly
        for reproducible batch runs.
    asset_features
        Asset attributes for stage 2, e.g.
        ``{"asset_type": "Bridge", "has_redundancy": "No"}``.
    strategy
        Stage-2 strategy: ``"model"`` or ``"rules"``.
    return_trace
        Include the per-stage breakdown. On by default — this is the point.

    Returns
    -------
    dict
        The Priority-Model's response, plus ``asset_impact`` and, when
        requested, a ``trace`` of every stage.

    Raises
    ------
    ValidationError
        Bad input (HTTP 400).
    UpstreamModelUnavailableError
        A sibling model could not be reached (HTTP 503).
    """
    traffic = validate_choice(traffic, config.TRAFFIC_LEVELS, "traffic")
    if due_date is None:
        raise ValidationError("due_date is required.")

    trace: dict[str, Any] = {}

    # ---- Stage 1: severity ----------------------------------------------- #
    if severity is not None:
        resolved_severity = validate_choice(severity, config.SEVERITY_LEVELS, "severity")
        severity_confidence = None
        trace["severity"] = {"value": resolved_severity, "source": "supplied",
                             "confidence": None}
    else:
        if reason_description is None:
            raise ValidationError(
                "Provide either reason_description (to be classified) or severity."
            )
        text = validate_text(reason_description, config.TEXT_COLUMN)
        stage1 = clients.predict_severity(text)
        resolved_severity = stage1["severity"]
        severity_confidence = stage1["confidence"]
        trace["severity"] = {
            "value": resolved_severity,
            "source": "maintenance_severity_model",
            "confidence": severity_confidence,
            "severity_score": stage1.get("severity_score"),
        }
        logger.debug("Stage 1: severity=%s (%.3f)", resolved_severity,
                     severity_confidence if severity_confidence is not None else -1)

    # ---- Stage 2: asset impact -------------------------------------------- #
    if asset_impact is not None:
        # A human-supplied value always wins. The point of stage 2 is to remove
        # a chore, not to overrule an engineer who has looked at the asset.
        resolved_impact = validate_choice(
            asset_impact, config.ASSET_IMPACT_LEVELS, "asset_impact"
        )
        trace["asset_impact"] = {"value": resolved_impact, "source": "supplied",
                                 "confidence": None}
    else:
        stage2 = predict_asset_impact(
            severity=resolved_severity,
            traffic=traffic,
            strategy=strategy,
            return_details=True,
            **(asset_features or {}),
        )
        resolved_impact = stage2["asset_impact"]
        trace["asset_impact"] = {
            "value": resolved_impact,
            "source": stage2["source"],
            "confidence": stage2["confidence"],
            "low_confidence": stage2.get("low_confidence"),
            "probabilities": stage2.get("probabilities"),
            "features_supplied": stage2.get("features_supplied"),
        }
        logger.debug("Stage 2: asset_impact=%s (%s)", resolved_impact, stage2["source"])

    # ---- Stage 3: priority ------------------------------------------------ #
    # severity= is passed so the Priority-Model does not re-run the NLP model.
    result = clients.predict_priority(
        asset_impact=resolved_impact,
        traffic=traffic,
        due_date=due_date,
        severity=resolved_severity,
        request_date=request_date,
    )
    trace["priority"] = {"source": "priority_model", "response": dict(result)}

    response: dict[str, Any] = dict(result)
    response["asset_impact"] = resolved_impact
    if severity_confidence is not None:
        response["severity_confidence"] = severity_confidence
    if return_trace:
        response["trace"] = trace

    audit_log({
        "stage": "full_pipeline",
        "inputs": {
            "reason_description": reason_description,
            "traffic": traffic,
            "due_date": str(due_date),
            "request_date": str(request_date) if request_date else None,
            "asset_features": asset_features,
        },
        "severity": resolved_severity,
        "asset_impact": resolved_impact,
        "priority_score": result.get("priority_score"),
        "priority_class": result.get("priority_class"),
    })
    return response


def score_requests(
    requests: Iterable[dict[str, Any]], *, strategy: str | None = None
) -> list[dict[str, Any]]:
    """
    Score many requests. One failure does not sink the batch.

    Failures come back as ``{"index": i, "error": ..., "error_type": ...}``.
    """
    results = []
    for index, request in enumerate(requests):
        try:
            results.append(score_request(**request, strategy=strategy))
        except AssetImpactError as exc:
            logger.error("Request %d failed: %s", index, exc)
            results.append({"index": index, "error": str(exc),
                            "error_type": type(exc).__name__})
        except Exception as exc:  # noqa: BLE001 - a sibling's own exception type
            logger.error("Request %d failed: %s", index, exc)
            results.append({"index": index, "error": str(exc),
                            "error_type": type(exc).__name__})
    return results


def health() -> dict[str, Any]:
    """Readiness of all three stages, for a ``/health`` endpoint. Never raises."""
    from src.predict import get_metadata, is_available

    # Widen the inferred type: availability() contains nested status metadata,
    # not only boolean values.
    status: dict[str, Any] = clients.availability()
    status["asset_impact"] = {"available": is_available()}
    if status["asset_impact"]["available"]:
        metadata = get_metadata()
        asset_impact_status = cast(dict[str, Any], status["asset_impact"])
        asset_impact_status.update({
            "model_name": metadata.get("model_name"),
            "trained_at": metadata.get("trained_at"),
            "uses_asset_attributes": metadata.get("uses_asset_attributes"),
            "beats_baseline": (metadata.get("holdout_metrics") or {}).get("beats_baseline"),
        })
    status["strategy"] = config.STRATEGY
    status["ready"] = all(
        s.get("available", False) for s in status.values() if isinstance(s, dict)
    ) or (
        config.STRATEGY == "rules"
        and status.get("severity", {}).get("available", False)
        and status.get("priority", {}).get("available", False)
    )
    return status


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def _main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a maintenance request through all three models.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python -m src.pipeline --reason 'Track fracture detected' \\\n"
            "      --traffic High --due-date 2026-09-25\n"
            "  python -m src.pipeline --reason 'Loose fittings' --traffic Low \\\n"
            "      --due-date 2026-12-01 --asset-type Bridge --has-redundancy No\n"
            "  python -m src.pipeline --health\n"
            "  python -m src.pipeline --input-csv requests.csv --output-csv scored.csv\n"
        ),
    )
    parser.add_argument("--reason", help="Free-text reason description.")
    parser.add_argument("--traffic", default="Medium")
    parser.add_argument("--due-date")
    parser.add_argument("--request-date")
    parser.add_argument("--severity", help="Skip stage 1.")
    parser.add_argument("--asset-impact", help="Skip stage 2 (manual override).")
    parser.add_argument("--strategy", choices=["model", "rules"], default=None)
    parser.add_argument("--asset-type")
    parser.add_argument("--line-type")
    parser.add_argument("--has-redundancy")
    parser.add_argument("--section-criticality")
    parser.add_argument("--asset-age-band")
    parser.add_argument("--no-trace", action="store_true")
    parser.add_argument("--health", action="store_true")
    parser.add_argument("--input-csv", type=Path)
    parser.add_argument("--output-csv", type=Path)
    args = parser.parse_args()

    if args.health:
        print(json.dumps(health(), indent=2, default=str))
        return

    asset_features = {
        k: v for k, v in {
            "asset_type": args.asset_type,
            "line_type": args.line_type,
            "has_redundancy": args.has_redundancy,
            "section_criticality": args.section_criticality,
            "asset_age_band": args.asset_age_band,
        }.items() if v is not None
    }

    try:
        if args.input_csv:
            import pandas as pd

            frame = pd.read_csv(args.input_csv)
            results = score_requests(
                cast(Iterable[dict[str, Any]], frame.to_dict("records")),
                strategy=args.strategy,
            )
            scored = pd.concat(
                [frame, pd.DataFrame([{k: v for k, v in r.items() if k != "trace"}
                                      for r in results])],
                axis=1,
            )
            if args.output_csv:
                scored.to_csv(args.output_csv, index=False)
                logger.info("Wrote %d scored row(s) to %s", len(scored), args.output_csv)
            else:
                print(scored.to_string(index=False))
            return

        if not args.due_date:
            parser.error("--due-date is required unless --health or --input-csv is used.")

        result = score_request(
            reason_description=args.reason,
            traffic=args.traffic,
            due_date=args.due_date,
            severity=args.severity,
            asset_impact=args.asset_impact,
            request_date=args.request_date,
            asset_features=asset_features or None,
            strategy=args.strategy,
            return_trace=not args.no_trace,
        )
        print(json.dumps(result, indent=2, default=str))

    except Exception as exc:  # noqa: BLE001
        logger.error("%s: %s", type(exc).__name__, exc)
        raise SystemExit(1) from exc


if __name__ == "__main__":
    _main()
