"""
config.py
=========
Single source of truth for paths, feature definitions, model settings and the
locations of the two sibling projects.

Why this file exists
--------------------
The feature list here is the most important setting in the project. It starts
as the two fields you asked for, and it is written so that adding asset
attributes later is a one-line change rather than a rewrite — which matters,
because ``reports/signal_analysis.json`` will tell you those attributes are
what this model actually needs. See the README.

Environment overrides
---------------------
    ASSET_IMPACT_SEVERITY_MODEL_PATH   path to Maintenance-Severity-Model
    ASSET_IMPACT_PRIORITY_MODEL_PATH   path to Priority-Model
    ASSET_IMPACT_STRATEGY              "model" | "rules"
    ASSET_IMPACT_LOG_LEVEL             DEBUG / INFO / WARNING / ERROR
"""

from __future__ import annotations

import os
from pathlib import Path

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
PROJECT_ROOT: Path = Path(__file__).resolve().parents[1]

DATA_DIR: Path = PROJECT_ROOT / "data"
RAW_DATA_DIR: Path = DATA_DIR / "raw"
MODELS_DIR: Path = PROJECT_ROOT / "models"
ARCHIVE_DIR: Path = MODELS_DIR / "archive"
LOGS_DIR: Path = PROJECT_ROOT / "logs"
REPORTS_DIR: Path = PROJECT_ROOT / "reports"

TRAINING_DATASET: Path = DATA_DIR / "asset_impact_training_data.csv"

MODEL_PATH: Path = MODELS_DIR / "asset_impact_model.joblib"
METADATA_PATH: Path = MODELS_DIR / "metadata.json"

APP_LOG_PATH: Path = LOGS_DIR / "app.log"
AUDIT_LOG_PATH: Path = LOGS_DIR / "predictions.jsonl"

# --------------------------------------------------------------------------- #
# Labels
# --------------------------------------------------------------------------- #
ASSET_IMPACT_LEVELS: list[str] = ["High", "Medium", "Low"]
SEVERITY_LEVELS: list[str] = ["Critical", "Major", "Moderate", "Minor"]
TRAFFIC_LEVELS: list[str] = ["High", "Medium", "Low"]

TARGET_COLUMN: str = "asset_impact"
SEVERITY_COLUMN: str = "reason_severity"
TRAFFIC_COLUMN: str = "traffic"
TEXT_COLUMN: str = "reason_description"

# --------------------------------------------------------------------------- #
# Features
# --------------------------------------------------------------------------- #
# The two fields you specified. Always used.
BASE_FEATURES: list[str] = [SEVERITY_COLUMN, TRAFFIC_COLUMN]

# Asset attributes. Any of these present in the dataset are added to the feature
# set automatically — no code change, no retraining script edit. These describe
# the *asset*, which is what "asset impact" is actually about: a signal failure
# on a double line with a diversion route is a different impact from the same
# failure on a single-line section with no alternative.
#
# Add your own column names here as your asset register grows.
OPTIONAL_ASSET_FEATURES: list[str] = [
    "asset_type",           # Track / Signalling / OHE / Bridge / Level Crossing / Points
    "line_type",            # Single / Double / Multiple
    "has_redundancy",       # Yes / No — is there a diversion or standby?
    "section_criticality",  # Trunk / Branch / Yard
    "asset_age_band",       # New / Mid-life / Ageing
]

# Numeric asset attributes, if you have them (e.g. daily tonnage, age in years).
OPTIONAL_NUMERIC_FEATURES: list[str] = []


def active_features(columns) -> tuple[list[str], list[str]]:
    """
    Decide which features to use given the columns actually present.

    Returns ``(categorical, numeric)``. Base features are required; optional
    ones join automatically when the dataset supplies them.
    """
    present = set(columns)
    categorical = [c for c in BASE_FEATURES if c in present]
    categorical += [c for c in OPTIONAL_ASSET_FEATURES if c in present]
    numeric = [c for c in OPTIONAL_NUMERIC_FEATURES if c in present]
    return categorical, numeric


# --------------------------------------------------------------------------- #
# Prediction strategy
# --------------------------------------------------------------------------- #
# "model" — use the trained classifier (what you asked for).
# "rules" — use the editable matrix below.
#
# Shipped as "rules", which is a change from what you asked for, so here is the
# reason. The signal analysis on your priority_training_data.csv returns
# verdict "no_signal": severity and traffic have Cramer's V of 0.017 against
# asset_impact, and the best possible classifier on them scores 0.4482 —
# exactly what you get by always answering "Medium". The model trained on that
# data scores 0.3220 with a Cohen's kappa of -0.01, i.e. no better than chance.
# Asset impact is worth up to 30 of the 100 priority points, so wiring a
# near-random value in there would quietly corrupt every score.
#
# Flip this to "model" the moment the signal analysis reports "usable" — which
# happens as soon as you add the asset attributes below. Per-call override:
# predict_asset_impact(..., strategy="model").
STRATEGY: str = os.getenv("ASSET_IMPACT_STRATEGY", "rules").strip().lower()

# Deterministic fallback: severity -> traffic -> asset impact.
# This is a starting point for domain experts to edit, not a derived truth.
RULES_MATRIX: dict[str, dict[str, str]] = {
    "Critical": {"High": "High", "Medium": "High", "Low": "Medium"},
    "Major": {"High": "High", "Medium": "Medium", "Low": "Medium"},
    "Moderate": {"High": "Medium", "Medium": "Medium", "Low": "Low"},
    "Minor": {"High": "Medium", "Medium": "Low", "Low": "Low"},
}

# --------------------------------------------------------------------------- #
# Dataset construction
# --------------------------------------------------------------------------- #
# At inference the asset-impact model receives a severity produced by the
# severity *model*. Training on human ground-truth severity instead would mean
# the model sees a different distribution in production than it saw in training
# — classic train/serve skew. So when raw text is available, regenerate the
# severity with the model rather than trusting a stored label.
PREFER_MODEL_PREDICTED_SEVERITY: bool = True

# Rows where the severity model disagrees with a stored ground-truth label are
# kept, but counted and reported: a high disagreement rate means the severity
# model needs attention before this one is trained on its output.
REPORT_SEVERITY_DISAGREEMENT: bool = True

# --------------------------------------------------------------------------- #
# Signal analysis thresholds
# --------------------------------------------------------------------------- #
# Cramer's V below this counts as "no usable association". 0.1 is the
# conventional line for a negligible effect size.
MIN_CRAMERS_V: float = 0.10

# A model must beat always-predicting-the-majority-class by at least this much
# accuracy to be worth deploying. Anything less is a constant with extra steps.
MIN_LIFT_OVER_BASELINE: float = 0.02

# Refuse to save a model that fails the lift check. Set False to save anyway
# (it is still written to reports/ either way).
BLOCK_SAVE_ON_NO_LIFT: bool = False

# --------------------------------------------------------------------------- #
# Training
# --------------------------------------------------------------------------- #
RANDOM_SEED: int = 42
TEST_SIZE: float = 0.20
CV_FOLDS: int = 5
SELECTION_METRIC: str = "f1_weighted"

# Same one-standard-error tie-break as the other two projects: among models
# statistically tied with the best, take the simplest.
USE_ONE_SE_RULE: bool = True
MODEL_COMPLEXITY_ORDER: list[str] = [
    "logistic_regression",
    "decision_tree",
    "random_forest",
    "xgboost",
]

LOGISTIC_REGRESSION_PARAMS: dict = {
    "C": 1.0,
    "max_iter": 2000,
    "class_weight": "balanced",
    "solver": "lbfgs",
}
DECISION_TREE_PARAMS: dict = {
    "max_depth": 8,
    "min_samples_leaf": 20,
    "class_weight": "balanced",
}
RANDOM_FOREST_PARAMS: dict = {
    "n_estimators": 300,
    "max_depth": 12,
    "min_samples_leaf": 5,
    "class_weight": "balanced_subsample",
    "n_jobs": -1,
}
XGBOOST_PARAMS: dict = {
    "n_estimators": 300,
    "max_depth": 5,
    "learning_rate": 0.1,
    "subsample": 0.9,
    "colsample_bytree": 0.9,
    "objective": "multi:softprob",
    "eval_metric": "mlogloss",
    "tree_method": "hist",
    "n_jobs": -1,
}

LOW_CONFIDENCE_THRESHOLD: float = 0.50

# --------------------------------------------------------------------------- #
# Sibling project integration
# --------------------------------------------------------------------------- #
SEVERITY_MODEL_PATH: Path | None = (
    Path(os.environ["ASSET_IMPACT_SEVERITY_MODEL_PATH"]).expanduser()
    if os.getenv("ASSET_IMPACT_SEVERITY_MODEL_PATH")
    else None
)
PRIORITY_MODEL_PATH: Path | None = (
    Path(os.environ["ASSET_IMPACT_PRIORITY_MODEL_PATH"]).expanduser()
    if os.getenv("ASSET_IMPACT_PRIORITY_MODEL_PATH")
    else None
)

SEVERITY_MODEL_SEARCH_PATHS: list[Path] = [
    PROJECT_ROOT.parent / "Maintenance-Severity-Model",
    PROJECT_ROOT.parent / "maintenance-severity-model",
    PROJECT_ROOT.parent / "severity-model",
]
PRIORITY_MODEL_SEARCH_PATHS: list[Path] = [
    PROJECT_ROOT.parent / "Priority-Model",
    PROJECT_ROOT.parent / "priority-model",
    PROJECT_ROOT.parent / "priority-engine",
]

SEVERITY_MODULE: str = "src.predict"
SEVERITY_FUNCTION: str = "predict_severity"
PRIORITY_MODULE: str = "src.predict"
PRIORITY_FUNCTION: str = "predict_priority"

# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
LOG_LEVEL: str = os.getenv("ASSET_IMPACT_LOG_LEVEL", "INFO").upper()
LOG_FORMAT: str = "%(asctime)s | %(levelname)-8s | %(name)-24s | %(message)s"
LOG_DATE_FORMAT: str = "%Y-%m-%d %H:%M:%S"
LOG_FILE_MAX_BYTES: int = 5 * 1024 * 1024
LOG_FILE_BACKUP_COUNT: int = 3
ENABLE_AUDIT_LOG: bool = True
