"""
utils.py
========
Logging, exception types, validation and persistence.

Why this file exists
--------------------
Same reasoning as the sibling projects: typed exceptions carry an HTTP status
so an API layer maps failures to codes instead of guessing; validators return
*canonical* values so nothing downstream worries about casing; logs go to
stderr so CLI JSON on stdout stays pipeable.

Kept deliberately consistent with ``Priority-Model/src/utils.py`` — three
projects with three different error vocabularies is how an integration layer
ends up with a bare ``except Exception``.
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Iterable, Mapping

import joblib

from src import config


# --------------------------------------------------------------------------- #
# Exceptions
# --------------------------------------------------------------------------- #
class AssetImpactError(Exception):
    """Base class for everything this package raises."""

    http_status: int = 500


class ValidationError(AssetImpactError):
    """Invalid caller input. HTTP 400."""

    http_status = 400


class DatasetError(AssetImpactError):
    """Training data missing or malformed. HTTP 500."""

    http_status = 500


class ModelNotTrainedError(AssetImpactError):
    """Artefacts missing — train.py has not run. HTTP 500."""

    http_status = 500


class UpstreamModelUnavailableError(AssetImpactError):
    """A sibling model (severity or priority) could not be reached. HTTP 503."""

    http_status = 503


class InsufficientSignalError(AssetImpactError):
    """The features carry no usable information about the target."""

    http_status = 500


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
_LOGGING_CONFIGURED = False


def setup_logging(force: bool = False) -> None:
    """Configure root logging once: stderr plus a rotating file in ``logs/``."""
    global _LOGGING_CONFIGURED
    if _LOGGING_CONFIGURED and not force:
        return

    config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
    formatter = logging.Formatter(config.LOG_FORMAT, datefmt=config.LOG_DATE_FORMAT)

    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(formatter)
    handlers: list[logging.Handler] = [console]

    try:
        file_handler = RotatingFileHandler(
            config.APP_LOG_PATH,
            maxBytes=config.LOG_FILE_MAX_BYTES,
            backupCount=config.LOG_FILE_BACKUP_COUNT,
            encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        handlers.append(file_handler)
    except OSError:
        pass  # read-only filesystem must not stop the service

    root = logging.getLogger()
    root.handlers.clear()
    for handler in handlers:
        root.addHandler(handler)
    root.setLevel(config.LOG_LEVEL)
    _LOGGING_CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    setup_logging()
    return logging.getLogger(name)


logger = get_logger(__name__)


def audit_log(record: Mapping[str, Any]) -> None:
    """Append one prediction to ``logs/predictions.jsonl``. Best-effort."""
    if not config.ENABLE_AUDIT_LOG:
        return
    try:
        config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
        payload = {"logged_at": datetime.now().isoformat(timespec="seconds"), **record}
        with config.AUDIT_LOG_PATH.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, default=str) + "\n")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not write to the audit log: %s", exc)


# --------------------------------------------------------------------------- #
# Persistence
# --------------------------------------------------------------------------- #
def ensure_dirs(*paths: Path) -> None:
    for path in paths:
        Path(path).mkdir(parents=True, exist_ok=True)


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def save_joblib(obj: Any, path: Path) -> None:
    path = Path(path)
    ensure_dirs(path.parent)
    try:
        joblib.dump(obj, path)
    except Exception as exc:
        raise AssetImpactError(f"Could not write {path}: {exc}") from exc
    logger.debug("Saved %s", path)


def load_joblib(path: Path) -> Any:
    path = Path(path)
    if not path.exists():
        raise ModelNotTrainedError(
            f"Missing artefact {path}. Train the model first:\n"
            f"    python -m src.build_dataset\n"
            f"    python -m src.train"
        )
    try:
        return joblib.load(path)
    except Exception as exc:
        raise AssetImpactError(
            f"Could not load {path} ({exc}). Corrupt, or written by an "
            f"incompatible scikit-learn version — retrain to fix."
        ) from exc


def save_json(obj: Any, path: Path) -> None:
    path = Path(path)
    ensure_dirs(path.parent)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False, default=str)
    logger.debug("Saved %s", path)


def load_json(path: Path) -> Any:
    path = Path(path)
    if not path.exists():
        raise AssetImpactError(f"Missing JSON file {path}.")
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
def validate_choice(value: Any, allowed: Iterable[str], field: str) -> str:
    """Validate a categorical input and return it in canonical casing."""
    allowed = list(allowed)
    if not isinstance(value, str):
        raise ValidationError(
            f"{field} must be a string, got {type(value).__name__}: {value!r}. "
            f"Accepted values: {allowed}."
        )
    cleaned = value.strip()
    if not cleaned:
        raise ValidationError(f"{field} must not be empty. Accepted values: {allowed}.")

    canonical = {option.lower(): option for option in allowed}.get(cleaned.lower())
    if canonical is None:
        raise ValidationError(f"{field} must be one of {allowed}, got {value!r}.")
    return canonical


def validate_text(value: Any, field: str, max_chars: int = 5000) -> str:
    if not isinstance(value, str):
        raise ValidationError(
            f"{field} must be a string, got {type(value).__name__}: {value!r}."
        )
    cleaned = value.strip()
    if not cleaned:
        raise ValidationError(f"{field} must not be empty or whitespace only.")
    if len(cleaned) > max_chars:
        raise ValidationError(f"{field} is {len(cleaned)} characters; limit is {max_chars}.")
    return cleaned


def normalise_column(series, allowed: Iterable[str]):
    """
    Map a column to canonical casing, leaving unrecognised values as NaN.

    Returned rather than raising, so the caller decides whether to drop the
    rows or fail — a data-cleaning step wants to drop, a request handler wants
    to fail.
    """
    lookup = {option.lower(): option for option in allowed}
    return series.astype(str).str.strip().str.lower().map(lookup)
