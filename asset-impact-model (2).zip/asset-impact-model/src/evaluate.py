"""
evaluate.py
===========
Metrics, classification reports and confusion matrices, plus the comparison
that decides whether this model is worth deploying at all.

Why this file exists
--------------------
Standard metrics on their own are misleading for this target. ``asset_impact``
is imbalanced (Medium is roughly 45% of your current data), so a model that has
learned nothing still reports about 45% accuracy and a respectable-looking
weighted F1. Every report this module writes therefore carries the
majority-class baseline beside the model's score, and the **lift** between
them. Lift is the number that matters: it is what the model adds over a
constant.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import cast

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)

from src import config  # noqa: E402
from src.utils import ensure_dirs, get_logger, save_json, timestamp  # noqa: E402

logger = get_logger(__name__)


def compute_metrics(y_true, y_pred, baseline_accuracy: float | None = None) -> dict:
    """
    All the standard metrics, plus three that matter for an imbalanced target.

    ``balanced_accuracy`` averages recall across classes, so a model that
    ignores the minority class cannot hide behind the majority one.
    ``cohen_kappa`` measures agreement above chance — near zero means the
    predictions are no better than guessing at the class frequencies.
    ``lift_over_baseline`` is accuracy minus what a constant would score.
    """
    labels = [c for c in config.ASSET_IMPACT_LEVELS if c in set(y_true) | set(y_pred)]
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, zero_division=0
    )
    precision_values = np.asarray(precision).ravel().tolist()
    recall_values = np.asarray(recall).ravel().tolist()
    f1_values = np.asarray(f1).ravel().tolist()
    support_values = np.asarray(support).ravel().tolist()
    accuracy = float(accuracy_score(y_true, y_pred))

    metrics = {
        "accuracy": accuracy,
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "cohen_kappa": float(cohen_kappa_score(y_true, y_pred)),
        "precision_weighted": float(
            precision_score(y_true, y_pred, average="weighted", zero_division=0)
        ),
        "recall_weighted": float(
            recall_score(y_true, y_pred, average="weighted", zero_division=0)
        ),
        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "precision_macro": float(
            precision_score(y_true, y_pred, average="macro", zero_division=0)
        ),
        "recall_macro": float(
            recall_score(y_true, y_pred, average="macro", zero_division=0)
        ),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "n_samples": int(len(y_true)),
        "per_class": {
            label: {
                "precision": float(p), "recall": float(r),
                "f1": float(f), "support": int(s),
            }
            for label, p, r, f, s in zip(
                labels, precision_values, recall_values, f1_values, support_values
            )
        },
    }

    if baseline_accuracy is None:
        baseline_accuracy = float(pd.Series(y_true).value_counts(normalize=True).max())
    metrics["majority_baseline_accuracy"] = round(baseline_accuracy, 4)
    metrics["lift_over_baseline"] = round(accuracy - baseline_accuracy, 4)
    metrics["beats_baseline"] = bool(
        metrics["lift_over_baseline"] >= config.MIN_LIFT_OVER_BASELINE
    )
    return metrics


def text_report(y_true, y_pred) -> str:
    labels = [c for c in config.ASSET_IMPACT_LEVELS if c in set(y_true) | set(y_pred)]
    report = classification_report(
        y_true, y_pred, labels=labels, digits=3, zero_division=0, output_dict=False
    )
    return cast(str, report)


def confusion_frame(y_true, y_pred) -> pd.DataFrame:
    labels = [c for c in config.ASSET_IMPACT_LEVELS if c in set(y_true) | set(y_pred)]
    return pd.DataFrame(
        confusion_matrix(y_true, y_pred, labels=labels),
        index=pd.Index(labels, name="true"),
        columns=pd.Index(labels, name="predicted"),
    )


def plot_confusion_matrix(
    cm: pd.DataFrame, output_path: Path, title: str, normalize: bool = False
) -> Path:
    ensure_dirs(output_path.parent)
    data = cm.to_numpy(dtype=float)
    if normalize:
        totals = data.sum(axis=1, keepdims=True)
        data = np.divide(data, totals, out=np.zeros_like(data), where=totals != 0)

    fig, ax = plt.subplots(figsize=(6.0, 5.0), dpi=150)
    im = ax.imshow(data, cmap="Blues", vmin=0, vmax=data.max() if data.max() else 1)
    ax.set_xticks(range(len(cm.columns)), cm.columns, rotation=30, ha="right")
    ax.set_yticks(range(len(cm.index)), cm.index)
    ax.set_xlabel("Predicted asset impact")
    ax.set_ylabel("True asset impact")
    ax.set_title(title)

    threshold = data.max() / 2 if data.max() else 0.5
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            value = f"{data[i, j]:.2f}" if normalize else f"{int(data[i, j])}"
            ax.text(j, i, value, ha="center", va="center",
                    color="white" if data[i, j] > threshold else "black", fontsize=10)

    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.tight_layout()
    fig.savefig(output_path)
    plt.close(fig)
    logger.info("Confusion matrix -> %s", output_path)
    return output_path


def feature_importances(pipeline, top_n: int = 20) -> dict | None:
    """
    Extract per-feature importance from the fitted pipeline where available.

    Worth reading closely: if the asset attributes dominate and severity and
    traffic sit near zero, that is the model telling you the same thing the
    signal analysis did.
    """
    try:
        names = list(pipeline.named_steps["preprocess"].get_feature_names_out())
        model = pipeline.named_steps["classifier"]

        if hasattr(model, "feature_importances_"):
            scores = np.asarray(model.feature_importances_, dtype=float)
        elif hasattr(model, "coef_"):
            # Multiclass linear: aggregate magnitude across the one-vs-rest rows.
            scores = np.abs(np.asarray(model.coef_, dtype=float)).mean(axis=0)
        else:
            return None

        order = np.argsort(scores)[::-1][:top_n]
        return {names[i]: round(float(scores[i]), 6) for i in order}
    except Exception as exc:  # noqa: BLE001 - diagnostic only, never fatal
        logger.debug("Could not extract feature importances: %s", exc)
        return None


def save_reports(
    y_true,
    y_pred,
    *,
    prefix: str = "holdout",
    baseline_accuracy: float | None = None,
    reports_dir: Path | None = None,
    extra: dict | None = None,
) -> dict:
    """Write the evidence bundle under ``reports/`` and return the metrics."""
    reports_dir = reports_dir or config.REPORTS_DIR
    ensure_dirs(reports_dir)

    metrics = compute_metrics(y_true, y_pred, baseline_accuracy)
    if extra:
        metrics.update(extra)

    report = text_report(y_true, y_pred)
    (reports_dir / f"{prefix}_classification_report.txt").write_text(
        f"{prefix} classification report — generated {timestamp()}\n\n{report}\n"
        f"Majority-class baseline accuracy: {metrics['majority_baseline_accuracy']:.4f}\n"
        f"Model accuracy:                   {metrics['accuracy']:.4f}\n"
        f"Lift over baseline:               {metrics['lift_over_baseline']:+.4f}\n",
        encoding="utf-8",
    )

    cm = confusion_frame(y_true, y_pred)
    cm.to_csv(reports_dir / f"{prefix}_confusion_matrix.csv")
    plot_confusion_matrix(cm, reports_dir / f"{prefix}_confusion_matrix.png",
                          f"Asset impact confusion matrix ({prefix})")
    plot_confusion_matrix(cm, reports_dir / f"{prefix}_confusion_matrix_normalized.png",
                          f"Asset impact — row-normalised ({prefix})", normalize=True)
    save_json(metrics, reports_dir / f"{prefix}_metrics.json")

    logger.info(
        "%s — accuracy %.4f (baseline %.4f, lift %+.4f) | balanced acc %.4f | "
        "kappa %.4f | F1 %.4f (macro %.4f, n=%d)",
        prefix, metrics["accuracy"], metrics["majority_baseline_accuracy"],
        metrics["lift_over_baseline"], metrics["balanced_accuracy"],
        metrics["cohen_kappa"], metrics["f1_weighted"], metrics["f1_macro"],
        metrics["n_samples"],
    )
    if not metrics["beats_baseline"]:
        logger.warning(
            "This model does not beat always predicting the majority class "
            "(lift %+.4f, threshold %+.4f). Deploying it would add latency and "
            "a failure mode without adding information.",
            metrics["lift_over_baseline"], config.MIN_LIFT_OVER_BASELINE,
        )

    print(f"\n=== {prefix} classification report ===\n{report}")
    print(f"=== {prefix} confusion matrix (rows = true) ===\n{cm}\n")
    return metrics


def evaluate_saved_model(data_path: Path | None = None, prefix: str = "evaluation") -> dict:
    """Score the persisted pipeline against a labelled dataset."""
    from src.predict import get_pipeline

    frame = pd.read_csv(data_path or config.TRAINING_DATASET)
    pipeline = get_pipeline()
    features = list(pipeline.feature_names_in_) if hasattr(pipeline, "feature_names_in_") else None
    if features is None:
        features, _ = config.active_features(frame.columns)

    y_true = frame[config.TARGET_COLUMN].tolist()
    y_pred = list(pipeline.predict(frame[features]))
    return save_reports(y_true, y_pred, prefix=prefix,
                        extra={"evaluated_at": timestamp(), "dataset": str(data_path)})


def _main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate the saved asset-impact model.")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--prefix", default="evaluation")
    args = parser.parse_args()
    evaluate_saved_model(args.data, prefix=args.prefix)


if __name__ == "__main__":
    _main()
