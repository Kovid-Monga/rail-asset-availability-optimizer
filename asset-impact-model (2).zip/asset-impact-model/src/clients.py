"""
clients.py
==========
The single seam between this project and the two sibling projects.

Why this file exists
--------------------
Every import of ``Maintenance-Severity-Model`` and ``Priority-Model`` goes
through here. When either project changes its layout, one file changes. When
one is replaced by a network service, one file changes.

The package-name collision
--------------------------
All three projects lay their code out under a package called ``src``. By the
time this runs, *our* ``src`` is already in ``sys.modules``, so a plain
``import_module("src.predict")`` returns **our** predict module — and the
failure looks like a missing function rather than a name clash, which is a
genuinely confusing half hour.

``_import_isolated`` handles it: stash our ``src.*`` entries, clear them,
import with the target project first on ``sys.path`` so its internal
``from src import config`` resolves to its own package, then restore ours. Both
sibling modules are imported this way and cached, so the swap happens once per
process.

The constraint this leaves is that a sibling must not perform a *lazy*
``import src.x`` after loading — by then ``src`` means this project again. Both
siblings bind what they need at module import time, so this is safe today. The
durable fix is to give each project a unique package name and pip-install it;
then set ``SEVERITY_MODULE`` / ``PRIORITY_MODULE`` accordingly and the isolation
code short-circuits because there is no collision.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Any, Callable, cast

from src import config
from src.utils import (
    UpstreamModelUnavailableError,
    ValidationError,
    get_logger,
    validate_choice,
    validate_text,
)

logger = get_logger(__name__)

_CACHE: dict[str, Callable[..., Any]] = {}
_RESOLVED: dict[str, Path] = {}


def _import_isolated(project_path: Path, module_name: str):
    """Import ``module_name`` from ``project_path``, surviving a package-name clash."""
    top_level = module_name.split(".", 1)[0]

    if top_level not in sys.modules:
        if str(project_path) not in sys.path:
            sys.path.insert(0, str(project_path))
        return importlib.import_module(module_name)

    stashed = {
        name: module
        for name, module in sys.modules.items()
        if name == top_level or name.startswith(top_level + ".")
    }
    original_path = list(sys.path)
    try:
        for name in stashed:
            del sys.modules[name]
        sys.path.insert(0, str(project_path))
        return importlib.import_module(module_name)
    finally:
        for name in list(sys.modules):
            if name == top_level or name.startswith(top_level + "."):
                del sys.modules[name]
        sys.modules.update(stashed)
        sys.path[:] = original_path


def _candidates(explicit: Path | None, search_paths: list[Path]) -> list[Path]:
    paths = ([explicit] if explicit else []) + list(search_paths)
    seen: set[Path] = set()
    unique: list[Path] = []
    for path in paths:
        resolved = path.expanduser().resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(resolved)
    return unique


def _load(kind: str, explicit, search_paths, module_name, function_name, env_var):
    """Locate, import and cache one sibling project's entry-point function."""
    if kind in _CACHE:
        return _CACHE[kind]

    tried: list[str] = []
    for path in _candidates(explicit, search_paths):
        module_file = path / Path(module_name.replace(".", "/") + ".py")
        if not module_file.exists():
            tried.append(f"{path} (no {module_name})")
            continue
        try:
            module = _import_isolated(path, module_name)
            fn = getattr(module, function_name)
            _CACHE[kind] = fn
            _RESOLVED[kind] = path
            logger.info("Loaded the %s model from %s", kind, path)
            return fn
        except Exception as exc:  # noqa: BLE001
            tried.append(f"{path} ({type(exc).__name__}: {exc})")

    raise UpstreamModelUnavailableError(
        f"Could not load the {kind} model.\nTried:\n  - " + "\n  - ".join(tried)
        + f"\n\nSet the path explicitly:\n  export {env_var}=/path/to/project\n"
        f"or place the project beside this one."
    )


# --------------------------------------------------------------------------- #
# Severity model (stage 1)
# --------------------------------------------------------------------------- #
def load_severity_model() -> Callable[..., dict]:
    return _load(
        "severity",
        config.SEVERITY_MODEL_PATH,
        config.SEVERITY_MODEL_SEARCH_PATHS,
        config.SEVERITY_MODULE,
        config.SEVERITY_FUNCTION,
        "ASSET_IMPACT_SEVERITY_MODEL_PATH",
    )


def predict_severity(reason_description: str) -> dict[str, Any]:
    """
    Call the severity model and normalise its result.

    The returned label is validated against this project's own list rather than
    trusted, so a stage-1 change that introduces a new severity fails here with
    a clear message instead of silently producing a wrong asset impact.
    """
    text = validate_text(reason_description, config.TEXT_COLUMN)
    fn = load_severity_model()
    try:
        raw = fn(text)
    except Exception as exc:  # noqa: BLE001
        raise UpstreamModelUnavailableError(
            f"The severity model raised {type(exc).__name__}: {exc}"
        ) from exc

    if not isinstance(raw, dict) or "severity" not in raw:
        raise ValidationError(
            f"The severity model returned {raw!r}; expected a dict with 'severity'."
        )
    return {
        "severity": validate_choice(raw["severity"], config.SEVERITY_LEVELS, "severity"),
        "severity_score": raw.get("score"),
        "confidence": (
            float(raw["confidence"]) if raw.get("confidence") is not None else None
        ),
    }


def predict_severity_batch(texts) -> list[dict[str, Any]]:
    """
    Score many remarks, preferring the sibling's own batch function if it has one.

    Building a training set means classifying thousands of historical remarks;
    a vectorised call is minutes faster than a loop, and the loop is only the
    fallback.
    """
    texts = [validate_text(t, config.TEXT_COLUMN) for t in texts]
    load_severity_model()
    path = _RESOLVED.get("severity")

    if path is not None:
        try:
            module = _import_isolated(path, config.SEVERITY_MODULE)
            batch_fn = getattr(module, "predict_batch", None)
            if callable(batch_fn):
                results = cast(list[dict[str, Any]], batch_fn(texts))
                return [
                    {
                        "severity": validate_choice(
                            r["severity"], config.SEVERITY_LEVELS, "severity"
                        ),
                        "severity_score": r.get("score"),
                        "confidence": r.get("confidence"),
                    }
                    for r in results
                ]
        except Exception as exc:  # noqa: BLE001
            logger.info("Batch severity call unavailable (%s); falling back to a loop.", exc)

    return [predict_severity(t) for t in texts]


# --------------------------------------------------------------------------- #
# Priority model (stage 2)
# --------------------------------------------------------------------------- #
def load_priority_model() -> Callable[..., dict]:
    return _load(
        "priority",
        config.PRIORITY_MODEL_PATH,
        config.PRIORITY_MODEL_SEARCH_PATHS,
        config.PRIORITY_MODULE,
        config.PRIORITY_FUNCTION,
        "ASSET_IMPACT_PRIORITY_MODEL_PATH",
    )


def predict_priority(
    asset_impact: str,
    traffic: str,
    due_date,
    *,
    severity: str,
    request_date=None,
    **kwargs,
) -> dict[str, Any]:
    """
    Call the priority model with an already-known severity.

    Passing ``severity=`` rather than the raw text is deliberate: the severity
    model has already run once in this pipeline, and letting stage 2 call it
    again would double the latency and — if the model were ever
    non-deterministic or reloaded mid-flight — risk the asset impact and the
    priority score being computed from two different severities.
    """
    fn = load_priority_model()
    try:
        return fn(
            asset_impact=asset_impact,
            traffic=traffic,
            due_date=due_date,
            severity=severity,
            request_date=request_date,
            **kwargs,
        )
    except Exception as exc:  # noqa: BLE001
        # A validation failure inside stage 2 is the caller's problem, not an
        # outage — re-raise it as-is so the status code stays correct.
        if type(exc).__name__ == "ValidationError":
            raise ValidationError(str(exc)) from exc
        raise UpstreamModelUnavailableError(
            f"The priority model raised {type(exc).__name__}: {exc}"
        ) from exc


# --------------------------------------------------------------------------- #
# Health
# --------------------------------------------------------------------------- #
def availability() -> dict[str, Any]:
    """Status of both siblings, for a ``/health`` endpoint. Never raises."""
    status: dict[str, Any] = {}
    for kind, loader in (("severity", load_severity_model), ("priority", load_priority_model)):
        try:
            loader()
            status[kind] = {"available": True, "path": str(_RESOLVED.get(kind))}
        except UpstreamModelUnavailableError as exc:
            status[kind] = {"available": False, "error": str(exc).splitlines()[0]}
    return status


def reset() -> None:
    """Clear the cache so the next call re-resolves. Used by tests."""
    _CACHE.clear()
    _RESOLVED.clear()
