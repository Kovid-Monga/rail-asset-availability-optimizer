"""
tests/test_diagnostics.py
=========================
Tests for the signal analysis.

Why these tests matter
----------------------
``diagnostics.analyse`` is the safeguard that stops this project from shipping
a model that has learned the class prior. If it ever reports "usable" on pure
noise, the warning everyone relies on goes silent and a random asset impact
starts feeding into safety-relevant priority scores. So both directions are
pinned here with synthetic data whose answer is known by construction: noise
must produce ``no_signal``, and a deterministic relationship must produce
``usable``.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from src import config, diagnostics


def _noise_frame(n: int = 2000, seed: int = 0) -> pd.DataFrame:
    """Features and target drawn independently: no relationship exists."""
    rng = np.random.default_rng(seed)
    return pd.DataFrame({
        config.SEVERITY_COLUMN: rng.choice(config.SEVERITY_LEVELS, n),
        config.TRAFFIC_COLUMN: rng.choice(config.TRAFFIC_LEVELS, n),
        config.TARGET_COLUMN: rng.choice(config.ASSET_IMPACT_LEVELS, n, p=[0.3, 0.45, 0.25]),
    })


def _signal_frame(n: int = 2000, seed: int = 0) -> pd.DataFrame:
    """Target is a deterministic function of one feature."""
    rng = np.random.default_rng(seed)
    severity = rng.choice(config.SEVERITY_LEVELS, n)
    mapping = {"Critical": "High", "Major": "High", "Moderate": "Medium", "Minor": "Low"}
    return pd.DataFrame({
        config.SEVERITY_COLUMN: severity,
        config.TRAFFIC_COLUMN: rng.choice(config.TRAFFIC_LEVELS, n),
        config.TARGET_COLUMN: [mapping[s] for s in severity],
    })


# --------------------------------------------------------------------------- #
# The two directions that matter
# --------------------------------------------------------------------------- #
def test_pure_noise_is_reported_as_no_signal():
    result = diagnostics.analyse(_noise_frame())
    assert result["verdict"] == "no_signal"
    assert result["max_possible_lift"] < config.MIN_LIFT_OVER_BASELINE


def test_a_real_relationship_is_reported_as_usable():
    result = diagnostics.analyse(_signal_frame())
    assert result["verdict"] == "usable"
    assert result["ceiling_accuracy"] > 0.95


def test_cramers_v_is_near_zero_for_independent_columns():
    frame = _noise_frame(4000)
    v, p_value = diagnostics.cramers_v(frame[config.SEVERITY_COLUMN],
                                       frame[config.TARGET_COLUMN])
    assert v < config.MIN_CRAMERS_V
    assert p_value > 0.01


def test_cramers_v_is_high_for_a_deterministic_relationship():
    frame = _signal_frame(2000)
    v, p_value = diagnostics.cramers_v(frame[config.SEVERITY_COLUMN],
                                       frame[config.TARGET_COLUMN])
    assert v > 0.8
    assert p_value < 0.001


# --------------------------------------------------------------------------- #
# Ceiling accuracy is the headline number — pin its meaning
# --------------------------------------------------------------------------- #
def test_ceiling_equals_baseline_when_features_are_useless():
    frame = _noise_frame(4000)
    ceiling = diagnostics.ceiling_accuracy(
        frame, config.BASE_FEATURES, config.TARGET_COLUMN
    )
    baseline, _ = diagnostics.majority_baseline(frame, config.TARGET_COLUMN)
    assert abs(ceiling - baseline) < config.MIN_LIFT_OVER_BASELINE


def test_ceiling_is_perfect_for_a_deterministic_mapping():
    frame = _signal_frame(1000)
    assert diagnostics.ceiling_accuracy(
        frame, [config.SEVERITY_COLUMN], config.TARGET_COLUMN
    ) == 1.0


def test_ceiling_with_no_features_is_the_majority_rate():
    frame = _noise_frame(1000)
    baseline, _ = diagnostics.majority_baseline(frame, config.TARGET_COLUMN)
    assert diagnostics.ceiling_accuracy(frame, [], config.TARGET_COLUMN) == baseline


def test_no_model_can_beat_the_ceiling():
    """
    The ceiling is an upper bound, not an estimate.

    Fits an unconstrained tree — the most flexible thing that could overfit
    these features — and checks it still cannot exceed the bound.
    """
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.tree import DecisionTreeClassifier

    frame = _noise_frame(2000)
    ceiling = diagnostics.ceiling_accuracy(
        frame, config.BASE_FEATURES, config.TARGET_COLUMN
    )
    model = Pipeline([
        ("encode", OneHotEncoder(handle_unknown="ignore")),
        ("tree", DecisionTreeClassifier(random_state=0)),
    ]).fit(frame[config.BASE_FEATURES], frame[config.TARGET_COLUMN])

    accuracy = np.mean(
        model.predict(frame[config.BASE_FEATURES])
        == frame[config.TARGET_COLUMN].to_numpy()
    )
    assert accuracy <= ceiling + 1e-9


# --------------------------------------------------------------------------- #
# Feature-set comparison
# --------------------------------------------------------------------------- #
def test_asset_features_raise_the_ceiling_on_the_demo_data():
    """The comparison that settles the design question."""
    from src.build_dataset import generate_demo_dataset

    frame = generate_demo_dataset(2000)
    comparison = diagnostics.compare_feature_sets(frame)
    assert comparison["gain_from_asset_features"] > 0.2
    assert comparison["combined_ceiling"] > comparison["base_ceiling"]


def test_comparison_handles_a_dataset_with_no_asset_features():
    comparison = diagnostics.compare_feature_sets(_noise_frame(500))
    assert comparison["asset_features_available"] == []
    assert "combined_ceiling" not in comparison


if __name__ == "__main__":
    import sys

    sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent))
    from _runner import run_module

    raise SystemExit(run_module(sys.modules[__name__]))
